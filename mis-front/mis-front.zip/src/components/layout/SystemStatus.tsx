"use client";
import { useSyncWidget } from "@/sync/useSyncWidget";
import { ShieldCheck } from "lucide-react";

export default function SystemStatus(){
 const { online, queueCount, syncing, storage } = useSyncWidget();


  const queueParts: string[] = [];

  if (syncing) queueParts.push("Syncing...");
  if (queueCount > 0) queueParts.push(`${queueCount}`);

  const syncStatusText = storage.supported ? `${storage.percent}%` : "Ready";
  const syncQueueStatusText = queueParts.length ? queueParts.join(" | ") : "None";
  const syncStatusClass = !online
    ? "flex items-center gap-1.5 text-[10px] font-bold text-emerald-600 dark:text-emerald-400"
    : storage.critical
      ? "flex items-center gap-1.5 text-[10px] font-bold text-amber-700 border-amber-300"
      : storage.nearLimit
        ? "flex items-center gap-1.5 text-[10px] font-bold text-yellow-700 border-yellow-300"
        : "flex items-center gap-1.5 text-[10px] font-bold text-emerald-600 dark:text-emerald-400";


    return (
        <div className="border-t border-slate-200 bg-slate-50 p-4 dark:border-[#2a2a3e] dark:bg-[#0f0f15]">
            <div className="mb-3 flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase text-slate-500">System Status</span>
              <span className="flex items-center gap-1.5 text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                <ShieldCheck className="h-3 w-3" /> SECURE
              </span>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-500 dark:text-slate-400">Storage</span>
                <span className={syncStatusClass} title={storage.supported ? `Storage used: ${storage.percent}%` : "Storage monitor unavailable"}>
                  {syncStatusText}
                </span>
              </div>
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-500 dark:text-slate-400">Queue</span>
                <span className="font-mono text-slate-700 dark:text-white">{syncQueueStatusText}</span>
              </div>
            </div>
          </div>
    )
}