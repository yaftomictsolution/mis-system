"use client";

import { Provider } from "react-redux";
import { store } from "@/store/store";
import { useEffect } from "react";
import { hydrateAuth } from "@/store/auth/authSlice";
import { ThemeProvider } from './context/ThemeContext'
import CacheOnVisit from '@/pwa/CacheOnVisit';
import DebugRegister from '@/pwa/debugRegister';

function Bootstrap() {
  useEffect(() => {
    const token = localStorage.getItem("token");
    const user = localStorage.getItem("user");

    store.dispatch(
      hydrateAuth({
        token: token ? token : null,
        user: user ? JSON.parse(user) : null,
      })
    );
  }, []);

  return null;
}

export default function Providers({ children }: { children: React.ReactNode }) {
  return (
    <Provider store={store}>
      <DebugRegister />
      <CacheOnVisit />
      <Bootstrap />
      <ThemeProvider>{children}</ThemeProvider>
    </Provider>
  );
}
