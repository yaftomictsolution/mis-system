"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import RequirePermission from "@/components/auth/RequirePermission";
import { customersListLocal, customersPullToLocal } from "@/modules/customers/customers.repo";
import { PageHeader } from '@/components/ui/PageHeader';
import { Modal } from '../../../src/components/ui/modal';
import { FormField } from '../../../src/components/ui/FormField';

import { Plus } from 'lucide-react';

const PAGE_SIZE = 20;
//


export default function CustomersPage() {

  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const [total, setTotal] = useState(0);

  async function loadLocal(nextPage = page, nextSearch = search) {
    setLoading(true);

    const local = await customersListLocal({
      page: nextPage,
      pageSize: PAGE_SIZE,
      q: nextSearch,
    });

    setItems(local.items);
    setPage(local.page);
    setHasMore(local.hasMore);
    setTotal(local.total);
    setLoading(false);
  }

  async function refresh() {
    await loadLocal(1, search);

    try {
      await customersPullToLocal();
    } catch {}

    await loadLocal(1, search);
  }

  useEffect(() => {
    refresh();
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      loadLocal(1, search);
    }, 250);

    return () => window.clearTimeout(timer);
  }, [search]);

  useEffect(() => {
    const onSyncComplete = () => {
      refresh();
    };

    window.addEventListener("sync:complete", onSyncComplete as EventListener);

    return () => {
      window.removeEventListener("sync:complete", onSyncComplete as EventListener);
    };
  }, [search]);

  return (
    <RequirePermission permission="customers.view">
        <div className="p-6 lg:p-8 max-w-[1600px] mx-auto">
          <PageHeader title="Customers" subtitle="Manage client relationships and profiles">
            <button type="button"  className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors font-medium shadow-lg shadow-blue-500/20">
              <Plus size={18} /> Add Customer
            </button>
          </PageHeader>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h1 className="text-xl font-semibold">Customers</h1>
              <div className="flex gap-2">
                <button className="rounded-xl border bg-white px-3 py-2 text-sm" onClick={refresh}>
                  Refresh
                </button>
                <Link className="rounded-xl bg-black px-3 py-2 text-sm text-white" href="/customers/new">
                  New Customer
                </Link>
              </div>
            </div>
            <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search name, phone, email..."
                className="w-full rounded-xl border bg-white px-3 py-2 text-sm md:max-w-sm"
              />
              <div className="text-xs text-gray-500">Local records: {total}</div>
            </div>

            {loading && <div className="text-sm text-gray-500">Loading...</div>}

            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              {items.map((customer) => (
                <Link
                  key={customer.uuid}
                  href={`/customers/detail#${encodeURIComponent(customer.uuid)}`}
                  className="rounded-2xl border bg-white p-4 hover:bg-gray-50"
                >
                  <div className="font-semibold">{customer.first_name}</div>
                  <div className="text-sm text-gray-600">
                    {customer.phone_primary}
                    {customer.email ? ` - ${customer.email}` : ""}
                  </div>
                </Link>
              ))}
            </div>

            {!loading && items.length === 0 && (
              <div className="text-sm text-gray-600">No customers found in local cache.</div>
            )}

            <div className="flex items-center justify-between pt-2">
              <button
                className="rounded-xl border bg-white px-3 py-2 text-sm disabled:opacity-50"
                disabled={page <= 1 || loading}
                onClick={() => loadLocal(page - 1, search)}
              >
                Previous
              </button>
              <div className="text-xs text-gray-500">Page {page}</div>
              <button
                className="rounded-xl border bg-white px-3 py-2 text-sm disabled:opacity-50"
                disabled={!hasMore || loading}
                onClick={() => loadLocal(page + 1, search)}
              >
                Next
              </button>
            </div>
          </div>
        </div>
    </RequirePermission>
  );
}
