'use client'

import React, { useEffect, useState, createContext, useContext } from 'react'

type Theme = 'light' | 'dark'

interface ThemeContextType {
  theme: Theme
  toggleTheme: () => void
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>('dark')
  const [isReady, setIsReady] = useState(false)

  useEffect(() => {
    const saved = localStorage.getItem('theme') as Theme | null

    if (saved === 'light' || saved === 'dark') {
      setTheme(saved)
    } else {
      const root = window.document.documentElement
      if (root.classList.contains('light')) {
        setTheme('light')
      } else {
        setTheme('dark')
      }
    }

    setIsReady(true)
  }, [])

  useEffect(() => {
    if (!isReady) return
    const root = window.document.documentElement
    root.classList.remove('light', 'dark')
    root.classList.add(theme)
    localStorage.setItem('theme', theme)
  }, [theme, isReady])

  const toggleTheme = () => {
    if (!isReady) return
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'))
  }

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  )
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider')
  }
  return context
}
