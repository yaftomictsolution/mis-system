"use client";

import { useEffect } from "react";
import { runSyncOnce } from "./syncEngine";

export function useAutoSync() {
  useEffect(() => {
    console.log("AutoSync initialized");

    const onOnline = () => {
      console.log("Back online → syncing...");
      runSyncOnce();
    };

    window.addEventListener("online", onOnline);

    // try sync at start
    runSyncOnce();

    return () => window.removeEventListener("online", onOnline);
  }, []);
}
