"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useDispatch, useSelector } from "react-redux";
import type { AppDispatch, RootState } from "@/store/store";
import { fetchMe } from "@/store/auth/authSlice";

export default function AuthGate({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const dispatch = useDispatch<AppDispatch>();
  const { token, user } = useSelector((s: RootState) => s.auth);

  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;

    if (!token) router.replace("/login");
    else if (!user) dispatch(fetchMe());
  }, [hydrated, token, user, dispatch, router]);

  if (!hydrated) return null;
  if (!token) return null;

  return <>{children}</>;
}
