"use client";

import { useState } from "react";

type CustomerFormValues = {
  first_name: string;
  father_name: string;
  grandfather_name: string;
  phone_primary: string;
  phone_secondary: string;
  email: string;
  address: string;
};

type CustomerSubmitValues = {
  first_name: string;
  father_name: string | null;
  grandfather_name: string | null;
  phone_primary: string;
  phone_secondary: string | null;
  email: string | null;
  address: string | null;
};

type Props = {
  initial?: Partial<CustomerFormValues> | null;
  onSubmit: (values: CustomerSubmitValues) => Promise<void>;
  submitLabel?: string;
};

export default function CustomerForm({ initial, onSubmit, submitLabel = "Save" }: Props) {
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<CustomerFormValues>({
    first_name: initial?.first_name ?? "",
    father_name: initial?.father_name ?? "",
    grandfather_name: initial?.grandfather_name ?? "",
    phone_primary: initial?.phone_primary ?? "",
    phone_secondary: initial?.phone_secondary ?? "",
    email: initial?.email ?? "",
    address: initial?.address ?? "",
  });

  async function submit() {
    setSaving(true);
    try {
      await onSubmit({
        ...form,
        father_name: form.father_name || null,
        grandfather_name: form.grandfather_name || null,
        phone_secondary: form.phone_secondary || null,
        email: form.email || null,
        address: form.address || null,
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-4 rounded-2xl border bg-white p-5">
      <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
        <Input label="First Name" value={form.first_name} onChange={(v: string) => setForm({ ...form, first_name: v })} />
        <Input
          label="Phone Primary"
          value={form.phone_primary}
          onChange={(v: string) => setForm({ ...form, phone_primary: v })}
        />
      </div>

      <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
        <Input label="Father Name" value={form.father_name} onChange={(v: string) => setForm({ ...form, father_name: v })} />
        <Input
          label="Grandfather Name"
          value={form.grandfather_name}
          onChange={(v: string) => setForm({ ...form, grandfather_name: v })}
        />
      </div>

      <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
        <Input
          label="Phone Secondary"
          value={form.phone_secondary}
          onChange={(v: string) => setForm({ ...form, phone_secondary: v })}
        />
        <Input label="Email" value={form.email} onChange={(v: string) => setForm({ ...form, email: v })} />
      </div>

      <label className="block space-y-1">
        <div className="text-xs text-gray-500">Address</div>
        <textarea
          className="w-full rounded-xl border p-2"
          rows={3}
          value={form.address}
          onChange={(e) => setForm({ ...form, address: e.target.value })}
        />
      </label>

      <button
        onClick={submit}
        disabled={saving || !form.first_name || !form.phone_primary}
        className="rounded-xl bg-black px-4 py-2 text-white disabled:opacity-50"
      >
        {saving ? "Saving..." : submitLabel} (works offline)
      </button>
    </div>
  );
}

function Input({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return (
    <label className="space-y-1">
      <div className="text-xs text-gray-500">{label}</div>
      <input className="w-full rounded-xl border p-2" value={value} onChange={(e) => onChange(e.target.value)} />
    </label>
  );
}
