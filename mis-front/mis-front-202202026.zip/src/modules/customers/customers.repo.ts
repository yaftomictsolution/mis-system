import { db, type CustomerRow } from "@/db/localDB";
import { api } from "@/lib/api";
import { enqueueSync } from "@/sync/queue";

const RETENTION_DAYS = 180;
const CLEANUP_INTERVAL_MS = 24 * 60 * 60 * 1000;
const DEFAULT_PAGE_SIZE = 20;
const MAX_PAGE_SIZE = 100;
const PULL_PAGE_SIZE = 200;
const MAX_LOCAL_TEXT = 4000;
const CURSOR_KEY = "customers_sync_cursor";
const CLEANUP_KEY = "customers_last_cleanup_ms";

function online() {
  return typeof navigator !== "undefined" && navigator.onLine;
}

function readLocalNumber(key: string): number | null {
  if (typeof window === "undefined") return null;

  const raw = window.localStorage.getItem(key);
  if (!raw) return null;

  const parsed = Number(raw);
  return Number.isFinite(parsed) ? parsed : null;
}

function writeLocalNumber(key: string, value: number) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(key, String(value));
}

function readLocalString(key: string): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(key);
}

function writeLocalString(key: string, value: string) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(key, value);
}

function toTimestamp(value: unknown): number {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }

  const parsed = Date.parse(String(value ?? ""));
  return Number.isFinite(parsed) ? parsed : Date.now();
}

function normalizeNullableText(value: unknown, maxLength = 255): string | null {
  if (typeof value !== "string") return null;

  const trimmed = value.trim();
  if (!trimmed) return null;

  return trimmed.slice(0, maxLength);
}

function sanitizeCustomer(input: any): CustomerRow {
  return {
    uuid: String(input?.uuid ?? ""),
    first_name: String(input?.first_name ?? "").slice(0, 255),
    father_name: normalizeNullableText(input?.father_name, 255),
    grandfather_name: normalizeNullableText(input?.grandfather_name, 255),
    phone_primary: String(input?.phone_primary ?? "").slice(0, 50),
    phone_secondary: normalizeNullableText(input?.phone_secondary, 50),
    email: normalizeNullableText(input?.email, 255),
    // Prevent very large text/blob-like values from growing IndexedDB too much.
    address: normalizeNullableText(input?.address, MAX_LOCAL_TEXT),
    updated_at: toTimestamp(input?.updated_at ?? input?.server_updated_at),
  };
}

function customerMatchesQuery(row: CustomerRow, query: string): boolean {
  const q = query.toLowerCase();
  return (
    row.first_name.toLowerCase().includes(q) ||
    (row.father_name ?? "").toLowerCase().includes(q) ||
    (row.grandfather_name ?? "").toLowerCase().includes(q) ||
    row.phone_primary.toLowerCase().includes(q) ||
    (row.phone_secondary ?? "").toLowerCase().includes(q) ||
    (row.email ?? "").toLowerCase().includes(q)
  );
}

function parseCustomersApiPayload(payload: any): {
  list: any[];
  hasMore: boolean;
  serverTime: string;
} {
  if (Array.isArray(payload)) {
    return {
      list: payload,
      hasMore: false,
      serverTime: new Date().toISOString(),
    };
  }

  const directData = payload?.data;
  if (Array.isArray(directData)) {
    return {
      list: directData,
      hasMore: Boolean(payload?.meta?.has_more),
      serverTime: String(payload?.meta?.server_time ?? new Date().toISOString()),
    };
  }

  const nestedData = payload?.data?.data;
  if (Array.isArray(nestedData)) {
    const current = Number(payload?.data?.current_page ?? 1);
    const last = Number(payload?.data?.last_page ?? 1);

    return {
      list: nestedData,
      hasMore: current < last,
      serverTime: String(payload?.meta?.server_time ?? new Date().toISOString()),
    };
  }

  return {
    list: [],
    hasMore: false,
    serverTime: new Date().toISOString(),
  };
}

export type CustomersLocalQuery = {
  page?: number;
  pageSize?: number;
  q?: string;
};

export type CustomersLocalPage = {
  items: CustomerRow[];
  page: number;
  pageSize: number;
  total: number;
  hasMore: boolean;
};

export async function customersListLocal(query: CustomersLocalQuery = {}): Promise<CustomersLocalPage> {
  await customersRetentionCleanupIfDue();

  const page = Math.max(1, query.page ?? 1);
  const pageSize = Math.min(MAX_PAGE_SIZE, Math.max(1, query.pageSize ?? DEFAULT_PAGE_SIZE));
  const offset = (page - 1) * pageSize;
  const search = (query.q ?? "").trim().toLowerCase();

  if (!search) {
    const total = await db.customers.count();
    const items = await db.customers.orderBy("updated_at").reverse().offset(offset).limit(pageSize).toArray();
    return {
      items,
      page,
      pageSize,
      total,
      hasMore: offset + items.length < total,
    };
  }

  const collection = db.customers.orderBy("updated_at").reverse().filter((row) => customerMatchesQuery(row, search));
  const total = await collection.count();
  const items = await collection.offset(offset).limit(pageSize).toArray();

  return {
    items,
    page,
    pageSize,
    total,
    hasMore: offset + items.length < total,
  };
}

export async function customerGetLocal(uuid: string) {
  return db.customers.get(uuid);
}

export async function customersPullToLocal() {
  if (!online()) return { pulled: 0 };

  const since = readLocalString(CURSOR_KEY);
  let page = 1;
  let pulled = 0;
  let serverTime = new Date().toISOString();

  while (true) {
    const params: Record<string, string | number> = {
      offline: 1,
      page,
      per_page: PULL_PAGE_SIZE,
    };

    if (since && page === 1) {
      params.since = since;
    }

    const response = await api.get("/api/customers", { params });
    const parsed = parseCustomersApiPayload(response.data);

    const rows = parsed.list
      .map(sanitizeCustomer)
      .filter((row) => row.uuid && row.first_name && row.phone_primary);

    serverTime = parsed.serverTime;

    if (rows.length > 0) {
      await db.customers.bulkPut(rows);
      pulled += rows.length;
    }

    if (!parsed.hasMore || rows.length === 0) {
      break;
    }

    page += 1;
  }

  writeLocalString(CURSOR_KEY, serverTime);
  await customersRetentionCleanupIfDue();

  return { pulled };
}

export async function customerCreate(payload: any) {
  const uuid = crypto.randomUUID();
  const row = sanitizeCustomer({
    ...payload,
    uuid,
    updated_at: Date.now(),
  });

  await db.customers.put(row);

  await enqueueSync({
    entity: "customers",
    uuid,
    action: "create",
    payload: row,
  });

  if (online()) {
    try {
      const response = await api.post("/api/customers", row);
      const saved = sanitizeCustomer(response.data?.data ?? row);
      await db.customers.put(saved);
    } catch {}
  }

  return row;
}

export async function customerUpdate(uuid: string, patch: any) {
  const existing = await db.customers.get(uuid);
  if (!existing) throw new Error("Customer not found locally");

  const updated = sanitizeCustomer({
    ...existing,
    ...patch,
    uuid,
    updated_at: Date.now(),
  });

  await db.customers.put(updated);

  await enqueueSync({
    entity: "customers",
    uuid,
    action: "update",
    payload: updated,
  });

  if (online()) {
    try {
      const response = await api.put(`/api/customers/${uuid}`, updated);
      const saved = sanitizeCustomer(response.data?.data ?? updated);
      await db.customers.put(saved);
    } catch {}
  }

  return updated;
}

export async function customerDelete(uuid: string) {
  await db.customers.delete(uuid);

  await enqueueSync({
    entity: "customers",
    uuid,
    action: "delete",
    payload: {},
  });

  if (online()) {
    try {
      await api.delete(`/api/customers/${uuid}`);
    } catch {}
  }
}

export async function customersRetentionCleanup() {
  const cutoff = Date.now() - RETENTION_DAYS * 24 * 60 * 60 * 1000;
  const pending = await db.sync_queue.where("entity").equals("customers").toArray();
  const protectedUuids = new Set(pending.map((item) => item.uuid));
  const oldRows = await db.customers.where("updated_at").below(cutoff).toArray();
  const removableUuids = oldRows.filter((row) => !protectedUuids.has(row.uuid)).map((row) => row.uuid);

  if (removableUuids.length > 0) {
    await db.customers.bulkDelete(removableUuids);
  }

  return removableUuids.length;
}

export async function customersRetentionCleanupIfDue() {
  const now = Date.now();
  const last = readLocalNumber(CLEANUP_KEY);

  if (last !== null && now - last < CLEANUP_INTERVAL_MS) {
    return 0;
  }

  const removed = await customersRetentionCleanup();
  writeLocalNumber(CLEANUP_KEY, now);
  return removed;
}

