import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { api } from "@/lib/api";
import { computeCredHash } from "@/lib/crypto";

type User = {
  id: number;
  full_name: string;
  email: string;
  permissions: string[];
};

type AuthState = {
  token: string | null;
  user: User | null;
  status: "idle" | "loading" | "failed";
  error: string | null;
};

const initialState: AuthState = {
  token: null,
  user: null,
  status: "idle",
  error: null,
};

// ✅ login thunk
export const login = createAsyncThunk(
  "auth/login",
  async ({ email, password }: { email: string; password: string }, thunkAPI) => {
    try {
      const res = await api.post("/api/auth/login", { email, password });

      // expected: { token, user }
      const { token, user } = res.data;

      // persist for offline usage
      localStorage.setItem("token", token);
      localStorage.setItem("user", JSON.stringify(user));
      // keep an offline copy of the user so logout doesn't remove the ability to hydrate offline
      try {
        localStorage.setItem("offline_user", JSON.stringify(user));
        console.debug("authSlice: stored offline_user", user);
      } catch (err) {
        console.warn("authSlice: failed to store offline_user", err);
      }
      console.debug("authSlice: stored token", token);
      console.debug("authSlice: stored user", user);

      // store credential-derived hash so offline re-login can verify local creds
      try {
        const h = await computeCredHash(email, password);
        localStorage.setItem("cred_hash", h);
        console.debug("authSlice: stored cred_hash", h);
        // also store an offline token copy so offline login can restore a session
        localStorage.setItem("offline_token", token);
        console.debug("authSlice: stored offline_token", token);
      } catch (err) {
        // ignore hashing errors (crypto may not be available in some environments)
        console.warn("computeCredHash failed", err);
      }

      return { token, user };
    } catch (err: any) {
      return thunkAPI.rejectWithValue(err?.response?.data?.message || "Login failed");
    }
  }
);

// ✅ fetch current user
export const fetchMe = createAsyncThunk("auth/me", async (_, thunkAPI) => {
  try {
    const res = await api.get("/api/auth/me");
    const user = res.data.user;

    localStorage.setItem("user", JSON.stringify(user));
    return user;
  } catch (err: any) {
    return thunkAPI.rejectWithValue("Unauthorized");
  }
});

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    hydrateAuth(state, action) {
      state.token = action.payload.token;
      state.user = action.payload.user;
    },
    logoutLocal(state) {
      state.token = null;
      state.user = null;
      state.status = "idle";
      state.error = null;

      localStorage.removeItem("token");
      localStorage.removeItem("user");
      // keep `cred_hash` and `offline_token` so an explicit logout
      // doesn't prevent offline re-login. To fully clear offline
      // credentials use the `clearOfflineCredentials` action.
    },
    clearOfflineCredentials(state) {
      localStorage.removeItem("cred_hash");
      localStorage.removeItem("offline_token");
      localStorage.removeItem("offline_user");
    },
  },
  extraReducers(builder) {
    builder
      .addCase(login.pending, (state) => {
        state.status = "loading";
        state.error = null;
      })
      .addCase(login.fulfilled, (state, action) => {
        state.status = "idle";
        state.token = action.payload.token;
        state.user = action.payload.user;
      })
      .addCase(login.rejected, (state, action: any) => {
        state.status = "failed";
        state.error = action.payload || "Login failed";
      })
      .addCase(fetchMe.fulfilled, (state, action) => {
        state.user = action.payload as any;
      });
  },
});

export const { hydrateAuth, logoutLocal, clearOfflineCredentials } = authSlice.actions;
export default authSlice.reducer;
