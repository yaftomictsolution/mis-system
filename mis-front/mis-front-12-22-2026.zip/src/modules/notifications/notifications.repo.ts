import { api } from "@/lib/api";

type Obj = Record<string, unknown>;

export type AdminNotificationRow = {
  id: string;
  type: string;
  category: string | null;
  title: string;
  message: string;
  sale_uuid: string | null;
  sale_id: string | null;
  read_at: string | null;
  created_at: string | null;
  data: Obj;
};

export type AdminNotificationPage = {
  items: AdminNotificationRow[];
  page: number;
  perPage: number;
  total: number;
  hasMore: boolean;
};

const asObj = (value: unknown): Obj => (typeof value === "object" && value !== null ? (value as Obj) : {});

function toRow(input: unknown): AdminNotificationRow {
  const row = asObj(input);
  return {
    id: String(row.id ?? ""),
    type: String(row.type ?? ""),
    category: row.category == null ? null : String(row.category),
    title: String(row.title ?? "Notification"),
    message: String(row.message ?? ""),
    sale_uuid: row.sale_uuid == null ? null : String(row.sale_uuid),
    sale_id: row.sale_id == null ? null : String(row.sale_id),
    read_at: row.read_at == null ? null : String(row.read_at),
    created_at: row.created_at == null ? null : String(row.created_at),
    data: asObj(row.data),
  };
}

export async function notificationsListMine(params: {
  page?: number;
  perPage?: number;
  unreadOnly?: boolean;
} = {}): Promise<AdminNotificationPage> {
  const page = Math.max(1, params.page ?? 1);
  const perPage = Math.max(1, Math.min(100, params.perPage ?? 20));

  const res = await api.get("/api/notifications", {
    params: {
      page,
      per_page: perPage,
      unread_only: params.unreadOnly ? 1 : 0,
    },
  });

  const root = asObj(res.data);
  const data = Array.isArray(root.data) ? root.data : [];
  const meta = asObj(root.meta);
  const items = data.map(toRow);

  return {
    items,
    page: Number(meta.page ?? page) || page,
    perPage: Number(meta.per_page ?? perPage) || perPage,
    total: Number(meta.total ?? items.length) || items.length,
    hasMore: Boolean(meta.has_more),
  };
}

export async function notificationMarkRead(id: string): Promise<void> {
  if (!id) return;
  await api.post(`/api/notifications/${id}/read`);
}

export async function notificationMarkAllRead(): Promise<void> {
  await api.post("/api/notifications/read-all");
}

