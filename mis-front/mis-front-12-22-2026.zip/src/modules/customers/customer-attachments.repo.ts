import { db, type PendingAttachmentRow } from "@/db/localDB";
import { api } from "@/lib/api";

const isOnline = () => typeof navigator !== "undefined" && navigator.onLine;

function emitQueueChanged(): void {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent("sync:queue:changed"));
}

function getApiStatus(error: unknown): number | undefined {
  return (error as { response?: { status?: number } }).response?.status;
}

function isNonRetryableAttachmentError(status?: number): boolean {
  return status === 400 || status === 404 || status === 409 || status === 410 || status === 422;
}

function toUploadFile(row: PendingAttachmentRow): File | Blob {
  if (typeof File !== "undefined") {
    return new File([row.file_blob], row.file_name || "attachment", { type: row.file_type || "application/octet-stream" });
  }
  return row.file_blob;
}

export async function customerAttachmentEnqueueLocal(customerUuid: string, file: File): Promise<void> {
  if (!customerUuid || !file) return;

  await db.pending_attachments.add({
    entity: "customers",
    entity_uuid: customerUuid,
    file_name: file.name,
    file_type: file.type || "application/octet-stream",
    file_size: file.size,
    file_blob: file,
    created_at: Date.now(),
  });
  emitQueueChanged();
}

export async function customerAttachmentDropByCustomerUuid(customerUuid: string): Promise<void> {
  if (!customerUuid) return;
  const rows = await db.pending_attachments.where("entity_uuid").equals(customerUuid).toArray();
  if (!rows.length) return;
  const ids = rows.map((row) => row.id).filter((id): id is number => id !== undefined);
  if (!ids.length) return;
  await db.pending_attachments.bulkDelete(ids);
  emitQueueChanged();
}

export async function customerAttachmentSyncPending(): Promise<{ synced: number }> {
  if (!isOnline()) return { synced: 0 };

  let synced = 0;
  const rows = await db.pending_attachments.orderBy("created_at").toArray();

  for (const row of rows) {
    if (row.id === undefined) continue;

    try {
      const form = new FormData();
      form.append("attachment", toUploadFile(row), row.file_name || "attachment");
      await api.post(`/api/customers/${row.entity_uuid}/attachments`, form);
      await db.pending_attachments.delete(row.id);
      emitQueueChanged();
      synced += 1;
    } catch (error: unknown) {
      const status = getApiStatus(error);
      if (isNonRetryableAttachmentError(status)) {
        await db.pending_attachments.delete(row.id);
        emitQueueChanged();
        continue;
      }
      break;
    }
  }

  return { synced };
}
