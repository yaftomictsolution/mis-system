import { api } from "@/lib/api";

type Obj = Record<string, unknown>;

export type CrmMessageRow = {
  id: number;
  customer_id: number;
  installment_id: number | null;
  installment_uuid: string | null;
  installment_no: number | null;
  installment_due_date: string | null;
  customer_name: string;
  customer_phone: string | null;
  customer_email: string | null;
  channel: "email" | "sms";
  message_type: string;
  status: "queued" | "sent" | "failed";
  error_message: string | null;
  metadata: Record<string, unknown> | null;
  sent_at: string | null;
  created_at: string | null;
};

export type CrmMessagePage = {
  items: CrmMessageRow[];
  page: number;
  perPage: number;
  total: number;
  hasMore: boolean;
};

export type CrmMessageCreatePayload = {
  customer_id: number;
  channel: "email" | "sms";
  message_type: string;
};

export type CrmReminderRunStats = {
  days: number;
  checked: number;
  attempted: number;
  sent: number;
  failed: number;
  skipped: number;
};

function obj(v: unknown): Obj {
  return typeof v === "object" && v !== null ? (v as Obj) : {};
}

function toRow(input: unknown): CrmMessageRow {
  const row = obj(input);
  return {
    id: Number(row.id ?? 0),
    customer_id: Number(row.customer_id ?? 0),
    installment_id: row.installment_id ? Number(row.installment_id) : null,
    installment_uuid: row.installment_uuid ? String(row.installment_uuid) : null,
    installment_no: row.installment_no ? Number(row.installment_no) : null,
    installment_due_date: row.installment_due_date ? String(row.installment_due_date) : null,
    customer_name: String(row.customer_name ?? ""),
    customer_phone: row.customer_phone ? String(row.customer_phone) : null,
    customer_email: row.customer_email ? String(row.customer_email) : null,
    channel: String(row.channel ?? "email") === "sms" ? "sms" : "email",
    message_type: String(row.message_type ?? ""),
    status: (["queued", "sent", "failed"].includes(String(row.status)) ? row.status : "queued") as CrmMessageRow["status"],
    error_message: row.error_message ? String(row.error_message) : null,
    metadata: row.metadata && typeof row.metadata === "object" ? (row.metadata as Record<string, unknown>) : null,
    sent_at: row.sent_at ? String(row.sent_at) : null,
    created_at: row.created_at ? String(row.created_at) : null,
  };
}

export async function crmMessagesList(params: {
  page?: number;
  perPage?: number;
  q?: string;
  status?: string;
  channel?: string;
  customerId?: number;
} = {}): Promise<CrmMessagePage> {
  const res = await api.get("/api/crm/messages", {
    params: {
      page: params.page ?? 1,
      per_page: params.perPage ?? 20,
      q: params.q || undefined,
      status: params.status || undefined,
      channel: params.channel || undefined,
      customer_id: params.customerId || undefined,
    },
  });

  const root = obj(res.data);
  const meta = obj(root.meta);
  const data = Array.isArray(root.data) ? root.data : [];

  return {
    items: data.map(toRow),
    page: Number(meta.page ?? params.page ?? 1),
    perPage: Number(meta.per_page ?? params.perPage ?? 20),
    total: Number(meta.total ?? data.length),
    hasMore: Boolean(meta.has_more),
  };
}

export async function crmMessageCreate(payload: CrmMessageCreatePayload): Promise<CrmMessageRow> {
  const res = await api.post("/api/crm/messages", payload);
  return toRow(obj(res.data).data);
}

export async function crmMessageRetry(id: number): Promise<CrmMessageRow> {
  const res = await api.post(`/api/crm/messages/${id}/retry`);
  return toRow(obj(res.data).data);
}

export async function crmRunInstallmentReminders(days = 10): Promise<CrmReminderRunStats> {
  const res = await api.post("/api/crm/reminders/run", { days });
  const data = obj(obj(res.data).data);
  return {
    days: Number(data.days ?? days),
    checked: Number(data.checked ?? 0),
    attempted: Number(data.attempted ?? 0),
    sent: Number(data.sent ?? 0),
    failed: Number(data.failed ?? 0),
    skipped: Number(data.skipped ?? 0),
  };
}
