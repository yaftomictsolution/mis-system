"use client";

import { useEffect } from "react";

const SW_ENABLED =
  process.env.NODE_ENV === "production" || process.env.NEXT_PUBLIC_ENABLE_SW === "true";

async function hasReachableWorkboxScript(): Promise<boolean> {
  try {
    const swRes = await fetch("/sw.js", { cache: "no-store" });
    if (!swRes.ok) return false;

    const swText = await swRes.text();
    const match = swText.match(/workbox-[a-z0-9]+\.js/i);
    if (!match) return true;

    const workboxRes = await fetch(`/${match[0]}`, { cache: "no-store" });
    return workboxRes.ok;
  } catch {
    return false;
  }
}

async function unregisterAllServiceWorkers(): Promise<void> {
  if (!("serviceWorker" in navigator)) return;
  const regs = await navigator.serviceWorker.getRegistrations();
  await Promise.all(regs.map((reg) => reg.unregister()));
}

async function clearAllCaches(): Promise<void> {
  if (!("caches" in window)) return;
  const names = await caches.keys();
  await Promise.all(names.map((name) => caches.delete(name)));
}

export default function DebugRegister() {
  useEffect(() => {
    if (!SW_ENABLED) return;

    if (!('serviceWorker' in navigator)) {
      console.warn('DebugRegister: serviceWorker not available in navigator');
      return;
    }

    void (async () => {
      try {
        const healthy = await hasReachableWorkboxScript();
        if (!healthy) {
          console.warn("DebugRegister: broken SW bundle detected, resetting SW + caches");
          await unregisterAllServiceWorkers();
          await clearAllCaches();
        }

        const reg = await navigator.serviceWorker.register("/sw.js", {
          scope: "/",
          updateViaCache: "none",
        });
        await reg.update().catch(() => undefined);
        console.info("DebugRegister: service worker ready", reg);
      } catch (err) {
        console.error("DebugRegister: registration failed", err);
      }
    })();
  }, []);

  return null;
}
