import Dexie, { Table } from "dexie";

export type ApiCacheRow = {
  key: string;
  data: unknown;
  updated_at: number;
  ttl_seconds: number;
};

export type SyncQueueRow = {
  id?: number;
  idempotency_key: string;
  entity: string;
  uuid: string;
  action: "create" | "update" | "delete";
  payload: unknown;
  created_at: number;
};

export type PendingAttachmentRow = {
  id?: number;
  entity: "customers";
  entity_uuid: string;
  file_name: string;
  file_type: string;
  file_size: number;
  file_blob: Blob;
  created_at: number;
};

export type SessionRow = {
  id?: number;
  token: string;
  user: unknown;
  cached_at: string;
  expires_at: string;
};

export type RoleRow = {

  uuid: string;
  name: string;
  guard_name?: string | null;
  permissions?: string[];
  updated_at: number;
};

export type CustomerRow = {
  id?: number;
  uuid: string;
  name: string;
  fname?: string | null;
  gname?: string | null;
  phone: string;
  phone1?: string | null;
  email?: string | null;
  status?: string | null;
  address?: string | null;
  updated_at: number;
};

export type UserRow = {

  uuid: string;
  name: string;
  password: string;
  roles?: string[];
  email?: string | null;
  updated_at: number;
};

export type ApartmentRow = {
  id: number;
  uuid: string;  
  apartment_code: string;
  total_price?: number;
  usage_type:string;
  block_number: string;
  unit_number: string;
  floor_number: string;
  bedrooms: number;
  halls: number;
  bathrooms: number;
  kitchens: number;
  balcony: boolean;
  area_sqm: number;
  apartment_shape: string;
  corridor: string;
  qr_code: string;
  additional_info: string;
  status:string;
  updated_at: number;       // unix ms for conflict
};


export type ApartmentSaleRow = {
  
  id?: number;
  uuid: string;
  sale_id?: string;
  sale_date:number;
  total_price:number;
  discount:number;
  payment_type:string
  frequency_type?: string;
  interval_count?: number;
  installment_count?: number;
  first_due_date?: number;
  custom_dates?: Array<{
    installment_no: number;
    due_date: number;
    amount: number;
  }>;
  schedule_locked?: boolean;
  schedule_locked_at?: number | null;
  approved_at?: number | null;
  net_price?: number;
  actual_net_revenue?: number;
  deed_status?: "not_issued" | "eligible" | "issued";
  deed_issued_at?: number | null;
  deed_issued_by?: number | null;
  key_handover_status?: "not_handed_over" | "handed_over" | "returned";
  key_handover_at?: number | null;
  key_handover_by?: number | null;
  possession_start_date?: number | null;
  vacated_at?: number | null;
  key_returned_at?: number | null;
  key_returned_by?: number | null;
  termination_reason?: string | null;
  termination_charge?: number;
  refund_amount?: number;
  remaining_debt_after_termination?: number;
  installments_count?: number;
  installments_paid_total?: number;
  has_paid_installments?: boolean;
  has_first_installment_paid?: boolean;
  can_handover_key?: boolean;
  edit_scope?: "full" | "limited" | "none";
  can_update?: boolean;
  can_delete?: boolean;
  customer_id: number;
  apartment_id: number;
  status: string;
  updated_at: number;
};

export type InstallmentRow = {
  id?: number;
  uuid: string;
  sale_id?: string;
  apartment_sale_id: number;
  installment_no: number;
  amount: number;
  due_date: number;
  paid_amount: number;
  paid_date?: number | null;
  remaining_amount?: number;
  status: string;
  sale_uuid?: string;
  apartment_id?: number;
  customer_id?: number;
  sale_status?: string;
  updated_at: number;
  created_at?: number;
};

export type ApartmentSaleFinancialRow = {
  id?: number;
  uuid: string;
  sale_uuid: string;
  apartment_sale_id?: number;
  accounts_status: string;
  municipality_share_15: number;
  delivered_to_municipality: number;
  remaining_municipality: number;
  company_share_85: number;
  delivered_to_company: number;
  rahnama_fee_1: number;
  customer_debt: number;
  discount_or_contractor_deduction: number;
  updated_at: number;
};

export type ApartmentRentalRow = {
  id?: number;
  uuid: string;
  rental_id: string;
  apartment_id: number;
  tenant_id: number;
  created_by?: number | null;
  contract_start: number;
  contract_end?: number | null;
  monthly_rent: number;
  advance_months: number;
  advance_required_amount: number;
  advance_paid_amount: number;
  advance_remaining_amount: number;
  total_paid_amount: number;
  advance_status: string;
  next_due_date?: number | null;
  status: string;
  key_handover_status: string;
  key_handover_at?: number | null;
  key_handover_by?: number | null;
  key_returned_at?: number | null;
  key_returned_by?: number | null;
  termination_reason?: string | null;
  terminated_at?: number | null;
  apartment_code?: string | null;
  apartment_unit?: string | null;
  tenant_name?: string | null;
  tenant_phone?: string | null;
  tenant_email?: string | null;
  updated_at: number;
  created_at: number;
};

export type RentalPaymentRow = {
  id?: number;
  uuid: string;
  bill_no?: string | null;
  bill_generated_at?: number | null;
  rental_id: number;
  rental_uuid?: string | null;
  rental_code?: string | null;
  tenant_id?: number | null;
  tenant_name?: string | null;
  tenant_phone?: string | null;
  apartment_id?: number | null;
  apartment_code?: string | null;
  period_month?: string | null;
  due_date?: number | null;
  payment_type: string;
  amount_due: number;
  amount_paid: number;
  remaining_amount: number;
  paid_date?: number | null;
  status: string;
  notes?: string | null;
  approved_by?: number | null;
  approved_at?: number | null;
  approved_by_name?: string | null;
  updated_at: number;
  created_at: number;
};


export class LocalDB extends Dexie {
  sync_queue!: Table<SyncQueueRow, number>;
  pending_attachments!: Table<PendingAttachmentRow, number>;
  session!: Table<SessionRow, number>;
  api_cache!: Table<ApiCacheRow, string>;
  customers!: Table<CustomerRow, string>;
  roles!: Table<RoleRow, string>;
  users!: Table<UserRow, string>;
  apartments!: Table<ApartmentRow, string>;
  apartment_sales!: Table<ApartmentSaleRow, string>;
  installments!: Table<InstallmentRow, string>;
  apartment_sale_financials!: Table<ApartmentSaleFinancialRow, string>;
  rentals!: Table<ApartmentRentalRow, string>;
  rental_payments!: Table<RentalPaymentRow, string>;

  
  constructor() {
    super("mis_local_db");

    this.version(1).stores({
      sync_queue: "++id, created_at, entity, uuid",
      session: "++id, expires_at",
      api_cache: "&key, updated_at",
    });

    this.version(2).stores({
      sync_queue: "++id, created_at, entity, uuid",
      session: "++id, expires_at",
      api_cache: "&key, updated_at",
      customers: "&uuid, updated_at, phone, name",
      roles: "&uuid, updated_at, name",
      users: "&uuid, updated_at, name,phone",
      apartments: "&uuid, updated_at, apartment_code, usage_type",
      apartment_sales: "&uuid, updated_at, sale_date, status",
    });

    this.version(3).stores({
      sync_queue: "++id, created_at, entity, uuid",
      session: "++id, expires_at",
      api_cache: "&key, updated_at",
      customers: "&uuid, updated_at, phone, name",
      roles: "&uuid, updated_at, name",
      users: "&uuid, updated_at, name,phone",
      apartments: "&uuid, updated_at, apartment_code, usage_type",
      apartment_sales: "&uuid, updated_at, sale_date, status, apartment_id, customer_id",
    });

    this.version(4).stores({
      sync_queue: "++id, created_at, entity, uuid",
      session: "++id, expires_at",
      api_cache: "&key, updated_at",
      customers: "&uuid, updated_at, phone, name",
      roles: "&uuid, updated_at, name",
      users: "&uuid, updated_at, name,phone",
      apartments: "&uuid, updated_at, apartment_code, usage_type",
      apartment_sales: "&uuid, updated_at, sale_date, status, apartment_id, customer_id",
      installments: "&uuid, updated_at, due_date, status, apartment_sale_id, sale_uuid",
    });

    this.version(5).stores({
      sync_queue: "++id, created_at, entity, uuid",
      session: "++id, expires_at",
      api_cache: "&key, updated_at",
      customers: "&uuid, updated_at, phone, name",
      roles: "&uuid, updated_at, name",
      users: "&uuid, updated_at, name,phone",
      apartments: "&uuid, updated_at, apartment_code, usage_type",
      apartment_sales: "&uuid, updated_at, sale_date, status, apartment_id, customer_id",
      installments: "&uuid, updated_at, due_date, status, apartment_sale_id, sale_uuid",
      apartment_sale_financials: "&sale_uuid, updated_at, apartment_sale_id",
    });

    this.version(6).stores({
      sync_queue: "++id, created_at, entity, uuid",
      pending_attachments: "++id, created_at, entity, entity_uuid",
      session: "++id, expires_at",
      api_cache: "&key, updated_at",
      customers: "&uuid, updated_at, phone, name",
      roles: "&uuid, updated_at, name",
      users: "&uuid, updated_at, name,phone",
      apartments: "&uuid, updated_at, apartment_code, usage_type",
      apartment_sales: "&uuid, updated_at, sale_date, status, apartment_id, customer_id",
      installments: "&uuid, updated_at, due_date, status, apartment_sale_id, sale_uuid",
      apartment_sale_financials: "&sale_uuid, updated_at, apartment_sale_id",
    });

    this.version(7).stores({
      sync_queue: "++id, created_at, entity, uuid",
      pending_attachments: "++id, created_at, entity, entity_uuid",
      session: "++id, expires_at",
      api_cache: "&key, updated_at",
      customers: "&uuid, updated_at, phone, name",
      roles: "&uuid, updated_at, name",
      users: "&uuid, updated_at, name,phone",
      apartments: "&uuid, updated_at, apartment_code, usage_type",
      apartment_sales: "&uuid, updated_at, sale_date, status, apartment_id, customer_id",
      installments: "&uuid, updated_at, due_date, status, apartment_sale_id, sale_uuid",
      apartment_sale_financials: "&sale_uuid, updated_at, apartment_sale_id",
      rentals: "&uuid, updated_at, status, apartment_id, tenant_id, rental_id, next_due_date",
      rental_payments: "&uuid, updated_at, rental_id, due_date, status, payment_type",
    });

    this.version(8).stores({
      sync_queue: "++id, created_at, entity, uuid",
      pending_attachments: "++id, created_at, entity, entity_uuid",
      session: "++id, expires_at",
      api_cache: "&key, updated_at",
      customers: "&uuid, updated_at, phone, name",
      roles: "&uuid, updated_at, name",
      users: "&uuid, updated_at, name,phone",
      apartments: "&uuid, updated_at, apartment_code, usage_type",
      apartment_sales: "&uuid, updated_at, sale_date, status, apartment_id, customer_id",
      installments: "&uuid, updated_at, due_date, status, apartment_sale_id, sale_uuid",
      apartment_sale_financials: "&sale_uuid, updated_at, apartment_sale_id",
      rentals: "&uuid, updated_at, status, apartment_id, tenant_id, rental_id, next_due_date",
      rental_payments: "&uuid, updated_at, rental_id, due_date, status, payment_type, tenant_id, rental_uuid",
    });

    this.version(9).stores({
      sync_queue: "++id, created_at, entity, uuid",
      pending_attachments: "++id, created_at, entity, entity_uuid",
      session: "++id, expires_at",
      api_cache: "&key, updated_at",
      customers: "&uuid, updated_at, phone, name",
      roles: "&uuid, updated_at, name",
      users: "&uuid, updated_at, name,phone",
      apartments: "&uuid, updated_at, apartment_code, usage_type",
      apartment_sales: "&uuid, updated_at, sale_date, status, apartment_id, customer_id",
      installments: "&uuid, updated_at, due_date, status, apartment_sale_id, sale_uuid",
      apartment_sale_financials: "&sale_uuid, updated_at, apartment_sale_id",
      rentals: "&uuid, updated_at, status, apartment_id, tenant_id, rental_id, next_due_date",
      rental_payments: "&uuid, updated_at, rental_id, due_date, status, payment_type, tenant_id, rental_uuid, bill_no, approved_at",
    });
  }
}

export const db = new LocalDB();
