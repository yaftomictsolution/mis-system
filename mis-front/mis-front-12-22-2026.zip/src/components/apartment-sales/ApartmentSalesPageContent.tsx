﻿"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useSelector } from "react-redux";
import ApartmentSalesContentView from "@/components/apartment-sales/ApartmentSalesContentView";
import { ApartmentSaleExpandedRow } from "@/components/apartment-sales/ApartmentSaleExpandedRow";
import type { ApartmentSaleTerminateFormState } from "@/components/apartment-sales/ApartmentSaleDialogs";
import type { ApartmentRow, ApartmentSaleRow, CustomerRow } from "@/db/localDB";
import { createApartmentSalesColumns } from "@/components/apartment-sales/apartment-sale.columns";
import {
  createEmptyApartmentSaleForm,
  type ApartmentSaleFormData,
} from "@/components/apartment-sales/apartment-sale.type";
import {
  DEFAULTED_MIN_CHARGE_RATE,
  DEFAULTED_SUGGESTED_CHARGE_RATE,
  LOCAL_LIST_PAGE_SIZE,
  TERMINATED_SUGGESTED_CHARGE_RATE,
  buildSalePayload,
  customerRemainingAmount,
  resolveRowEditScope,
  toCurrency,
  toDateLabel,
  toForm,
  toMoney2,
} from "@/components/apartment-sales/apartment-sale.page-helpers";
import { loadAllSaleApartments, loadAllSaleCustomers } from "@/components/apartment-sales/apartment-sale.lookups";
import {
  apartmentSaleDelete,
  apartmentSaleHandoverKey,
  apartmentSaleIssueDeed,
  apartmentSaleListLocal,
  apartmentSalePullToLocal,
  apartmentSaleTerminate,
  apartmentSaleUpdate,
  type ApartmentSaleTerminateInput,
} from "@/modules/apartment-sales/apartment-sales.repo";


import { apartmentSaleMunicipalityRemainingMapLocal } from "@/modules/apartment-sale-financials/apartment-sale-financials.repo";
import { installmentsPaidTotalsBySaleUuidLocal, installmentsPullToLocal } from "@/modules/installments/installments.repo";
import { notifyError } from "@/lib/notify";
import { subscribeAppEvent } from "@/lib/appEvents";
import { apartmentsPullToLocal } from "@/modules/apartments/apartments.repo";
import { customersPullToLocal } from "@/modules/customers/customers.repo";
import type { RootState } from "@/store/store";

type ApartmentSalesPageContentProps = {
  refreshKey?: number;
};

type SelectOption = {
  value: string;
  label: string;
};

const READ_ONLY_MESSAGE = "Read-only access. You do not have permission to create/update/delete sales.";

function getStatus(value: unknown): string {
  return String(value ?? "").trim().toLowerCase();
}

function buildCustomerAssignedCount(rows: ApartmentSaleRow[]): Map<number, number> {
  const countByCustomer = new Map<number, number>();
  const seenCustomerApartment = new Set<string>();

  for (const sale of rows) {
    const customerId = Number(sale.customer_id);
    const apartmentId = Number(sale.apartment_id);
    const status = getStatus(sale.status);

    if (!Number.isFinite(customerId) || customerId <= 0) continue;
    if (!Number.isFinite(apartmentId) || apartmentId <= 0) continue;
    if (status === "cancelled" || status === "terminated" || status === "defaulted") continue;

    const uniqueKey = `${customerId}:${apartmentId}`;
    if (seenCustomerApartment.has(uniqueKey)) continue;

    seenCustomerApartment.add(uniqueKey);
    countByCustomer.set(customerId, (countByCustomer.get(customerId) ?? 0) + 1);
  }
  return countByCustomer;
}

function buildCustomerOptions(customers: CustomerRow[], assignedCountById: Map<number, number>): SelectOption[] {
  return customers
    .filter((item) => typeof item.id === "number" && item.id > 0)
    .map((item) => ({
      value: String(item.id),
      label: `${item.name} - Assigned: ${assignedCountById.get(item.id ?? 0) ?? 0}`,
    }))
    .sort((a, b) => a.label.localeCompare(b.label));
}

function buildApartmentOptions(
  apartments: ApartmentRow[],
  selectedApartmentId: string,
  isEditing: boolean
): SelectOption[] {
  return apartments
    .filter((item) => {
      if (typeof item.id !== "number" || item.id <= 0) return false;
      const isAvailable = getStatus(item.status) === "available";
      const isSelected = isEditing && String(item.id) === String(selectedApartmentId);
      return isAvailable || isSelected;
    })
    .map((item) => ({
      value: String(item.id),
      label: `${item.apartment_code} - Unit ${item.unit_number}`,
    }))
    .sort((a, b) => a.label.localeCompare(b.label));
}

function buildCustomerLabelMap(customers: CustomerRow[]): Map<number, string> {
  const map = new Map<number, string>();
  for (const item of customers) {
    if (!item.id || item.id <= 0) continue;
    map.set(item.id, item.name);
  }
  return map;
}

function buildApartmentLabelMap(apartments: ApartmentRow[]): Map<number, string> {
  const map = new Map<number, string>();
  for (const item of apartments) {
    if (!item.id || item.id <= 0) continue;
    map.set(item.id, `${item.apartment_code} - Unit ${item.unit_number}`);
  }
  return map;
}

function toPrintableValue(value: unknown, fallback = ""): string {
  const text = String(value ?? "").trim();
  return text || fallback;
}

function toPersianDate(value: number | null | undefined): string {
  const date = typeof value === "number" && Number.isFinite(value) ? new Date(value) : new Date();
  return new Intl.DateTimeFormat("fa-AF-u-ca-persian", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
}

function splitAddressParts(address: string | null | undefined, count: number): string[] {
  const raw = String(address ?? "").trim();
  if (!raw) {
    return Array.from({ length: count }, () => "");
  }

  const parts = raw
    .split(/[\n,/-]+/)
    .map((item) => item.trim())
    .filter(Boolean);

  while (parts.length < count) {
    parts.push("");
  }

  return parts.slice(0, count);
}

export default function ApartmentSalesPageContent({ refreshKey = 0 }: ApartmentSalesPageContentProps) {
  const permissions = useSelector((s: RootState) => s.auth.user?.permissions ?? []);
  const canManageSales = permissions.includes("sales.create");
  const canApproveDeed = permissions.includes("sales.approve");
  const readOnly = !canManageSales;

  const [rows, setRows] = useState<ApartmentSaleRow[]>([]);
  const [installmentPaidBySaleUuid, setInstallmentPaidBySaleUuid] = useState<Map<string, number>>(() => new Map());
  const [municipalityRemainingBySaleUuid, setMunicipalityRemainingBySaleUuid] = useState<Map<string, number>>(
    () => new Map()
  );
  const [customers, setCustomers] = useState<CustomerRow[]>([]);
  const [apartments, setApartments] = useState<ApartmentRow[]>([]);
  const [form, setForm] = useState<ApartmentSaleFormData>(createEmptyApartmentSaleForm());
  const [formError, setFormError] = useState<string | null>(null);
  const [editingUuid, setEditingUuid] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  const [pendingDelete, setPendingDelete] = useState<ApartmentSaleRow | null>(null);
  const [pendingHandover, setPendingHandover] = useState<ApartmentSaleRow | null>(null);
  const [handoverSubmitting, setHandoverSubmitting] = useState(false);
  const [handoverError, setHandoverError] = useState<string | null>(null);
  const [pendingTerminate, setPendingTerminate] = useState<ApartmentSaleRow | null>(null);
  const [terminateSubmitting, setTerminateSubmitting] = useState(false);
  const [terminateError, setTerminateError] = useState<string | null>(null);
  const [terminateForm, setTerminateForm] = useState<ApartmentSaleTerminateFormState>({
    reason: "",
    status: "terminated",
    vacated_at: new Date().toISOString().slice(0, 10),
    termination_charge: "0",
  });
  const [pendingIssueDeed, setPendingIssueDeed] = useState<ApartmentSaleRow | null>(null);
  const [deedIssuing, setDeedIssuing] = useState(false);
  const [deedIssueError, setDeedIssueError] = useState<string | null>(null);

  const isEditing = Boolean(editingUuid);

  const getSalePaidTotal = useCallback(
    (row?: ApartmentSaleRow | null): number => {
      if (!row) return 0;

      const paidFromMap = installmentPaidBySaleUuid.get(row.uuid);
      if (typeof paidFromMap === "number" && Number.isFinite(paidFromMap)) {
        return Math.max(0, toMoney2(paidFromMap));
      }

      const paidFromRow = Number(row.installments_paid_total ?? 0);
      if (Number.isFinite(paidFromRow)) {
        return Math.max(0, toMoney2(paidFromRow));
      }

      return 0;
    },
    [installmentPaidBySaleUuid]
  );

  const defaultedMinCharge = useCallback((paidTotal: number): number => {
    return toMoney2(Math.max(0, paidTotal) * DEFAULTED_MIN_CHARGE_RATE);
  }, []);

  const suggestedCharge = useCallback(
    (status: "terminated" | "defaulted", paidTotal: number): number => {
      const safePaid = Math.max(0, paidTotal);
      const rate = status === "defaulted" ? DEFAULTED_SUGGESTED_CHARGE_RATE : TERMINATED_SUGGESTED_CHARGE_RATE;
      const charge = toMoney2(safePaid * rate);

      if (status === "defaulted") {
        return Math.max(defaultedMinCharge(safePaid), charge);
      }
      return charge;
    },
    [defaultedMinCharge]
  );

  const loadLookups = useCallback(async () => {
    const [customerRows, apartmentRows] = await Promise.all([loadAllSaleCustomers(), loadAllSaleApartments()]);
    setCustomers(customerRows);
    setApartments(apartmentRows);
  }, []);

  const loadLocal = useCallback(async () => {
    const local = await apartmentSaleListLocal({ page: 1, pageSize: LOCAL_LIST_PAGE_SIZE });
    const localRows = local.items.map((item) => ({ ...item }));

    const [remainingMap, paidMap] = await Promise.all([
      apartmentSaleMunicipalityRemainingMapLocal(localRows.map((item) => item.uuid)),
      installmentsPaidTotalsBySaleUuidLocal(localRows.map((item) => item.uuid)),
    ]);

    const patchedRows = localRows.map((item) => {
      const paid = paidMap.get(item.uuid);
      if (typeof paid !== "number" || !Number.isFinite(paid)) return item;
      return {
        ...item,
        installments_paid_total: Number(paid.toFixed(2)),
        has_paid_installments: paid > 0,
      };
    });

    setRows(patchedRows);
    setMunicipalityRemainingBySaleUuid(remainingMap);
    setInstallmentPaidBySaleUuid(paidMap);
  }, []);

  const refresh = useCallback(async () => {
    setLoading(true);

    try {
      await Promise.all([loadLocal(), loadLookups()]);

      try {
        const [salesPull, installmentsPull, customersPull, apartmentsPull] = await Promise.all([
          apartmentSalePullToLocal(),
          installmentsPullToLocal(),
          customersPullToLocal(),
          apartmentsPullToLocal(),
        ]);

        const pulledAny =
          (salesPull?.pulled ?? 0) > 0 ||
          (installmentsPull?.pulled ?? 0) > 0 ||
          (customersPull?.pulled ?? 0) > 0 ||
          (apartmentsPull?.pulled ?? 0) > 0;

        if (pulledAny) {
          await Promise.all([loadLocal(), loadLookups()]);
        }
      } catch {
        // Keep local data if online pull fails.
      }
    } finally {
      setLoading(false);
    }
  }, [loadLocal, loadLookups]);

  useEffect(() => {
    void refresh();
  }, [refresh, refreshKey]);

  useEffect(() => {
    let loadingLocal = false;
    let loadingFull = false;
    let lastSyncAt = 0;
    let lastInstallmentEventAt = 0;

    const refreshLocalOnly = async () => {
      if (loadingLocal) return;
      loadingLocal = true;
      try {
        await loadLocal();
      } finally {
        loadingLocal = false;
      }
    };

    const refreshLocalAndLookups = async () => {
      if (loadingFull) return;
      loadingFull = true;
      try {
        await Promise.all([loadLocal(), loadLookups()]);
      } finally {
        loadingFull = false;
      }
    };

    const onSyncComplete = (event: Event) => {
      const syncedAny = Boolean((event as CustomEvent<{ syncedAny?: boolean }>).detail?.syncedAny);
      if (!syncedAny) return;

      const now = Date.now();
      if (now - lastSyncAt < 800) return;
      lastSyncAt = now;

      void refreshLocalAndLookups();
    };

    const onInstallmentsChanged = () => {
      const now = Date.now();
      if (now - lastInstallmentEventAt < 400) return;
      lastInstallmentEventAt = now;

      void refreshLocalOnly();
    };

    window.addEventListener("sync:complete", onSyncComplete as EventListener);
    const unsubscribeInstallmentsChanged = subscribeAppEvent("installments:changed", onInstallmentsChanged);

    return () => {
      window.removeEventListener("sync:complete", onSyncComplete as EventListener);
      unsubscribeInstallmentsChanged();
    };
  }, [loadLocal, loadLookups]);

  const customerAssignedCountById = useMemo(() => buildCustomerAssignedCount(rows), [rows]);
  const customerOptions = useMemo(
    () => buildCustomerOptions(customers, customerAssignedCountById),
    [customers, customerAssignedCountById]
  );
  const apartmentOptions = useMemo(
    () => buildApartmentOptions(apartments, form.apartment_id, isEditing),
    [apartments, form.apartment_id, isEditing]
  );
  const customerLabelById = useMemo(() => buildCustomerLabelMap(customers), [customers]);
  const apartmentLabelById = useMemo(() => buildApartmentLabelMap(apartments), [apartments]);

  const openHandoverDialog = useCallback(
    (row: ApartmentSaleRow) => {
      const status = getStatus(row.status);
      if (status === "cancelled" || status === "terminated" || status === "defaulted") {
        notifyError("Cannot hand over keys for cancelled/terminated/defaulted sale.");
        return;
      }
      if (getStatus(row.key_handover_status) === "handed_over") {
        notifyError("Key is already handed over.");
        return;
      }

      const hasInstallmentPayment = row.payment_type === "installment" && getSalePaidTotal(row) > 0;
      const canHandover = Boolean(row.can_handover_key || row.has_first_installment_paid || hasInstallmentPayment);
      if (!canHandover) {
        notifyError("At least one installment payment must be recorded before key handover.");
        return;
      }

      setHandoverError(null);
      setPendingHandover(row);
    },
    [getSalePaidTotal]
  );

  const openTerminateDialog = useCallback(
    (row: ApartmentSaleRow) => {
      const status = getStatus(row.status);
      if (status === "cancelled" || status === "terminated" || status === "defaulted" || status === "completed") {
        notifyError("Sale is already completed/cancelled/terminated/defaulted.");
        return;
      }
      if (getStatus(row.deed_status) === "issued") {
        notifyError("Cannot terminate sale after deed issuance.");
        return;
      }

      const paidTotal = getSalePaidTotal(row);
      setTerminateError(null);
      setTerminateForm({
        reason: "",
        status: "terminated",
        vacated_at: new Date().toISOString().slice(0, 10),
        termination_charge: String(suggestedCharge("terminated", paidTotal)),
      });
      setPendingTerminate(row);
    },
    [getSalePaidTotal, suggestedCharge]
  );

  const openIssueDeedDialog = useCallback(
    (row: ApartmentSaleRow) => {
      if (getStatus(row.deed_status) === "issued") {
        notifyError("Ownership deed is already issued for this sale.");
        return;
      }

      const status = getStatus(row.status);
      if (status === "cancelled" || status === "terminated" || status === "defaulted") {
        notifyError("Cannot issue deed for cancelled/terminated/defaulted sale.");
        return;
      }

      const municipalityRemaining = Number(municipalityRemainingBySaleUuid.get(row.uuid) ?? 0);
      if (municipalityRemaining > 0) {
        notifyError(`Municipality remaining must be zero before deed issuance. Remaining: $${municipalityRemaining.toFixed(2)}`);
        return;
      }

      const customerRemaining = customerRemainingAmount(row, installmentPaidBySaleUuid);
      if (customerRemaining > 0) {
        notifyError(`Customer payment is not complete yet. Remaining: $${customerRemaining.toFixed(2)}`);
        return;
      }

      setDeedIssueError(null);
      setPendingIssueDeed(row);
    },
    [installmentPaidBySaleUuid, municipalityRemainingBySaleUuid]
  );

  const printSaleDocument = useCallback(
    (row: ApartmentSaleRow) => {
      if (typeof window === "undefined") return;

      const escapeHtml = (value: string): string =>
        value
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;")
          .replace(/'/g, "&#39;");

      const customerLabel = customerLabelById.get(row.customer_id) ?? `Customer #${row.customer_id}`;
      const apartmentLabel = apartmentLabelById.get(row.apartment_id) ?? `Apartment #${row.apartment_id}`;
      const saleLabel = row.sale_id || row.uuid.slice(0, 8).toUpperCase();
      const saleDate = toDateLabel(row.sale_date);
      const totalPrice = toCurrency(Number(row.total_price ?? 0));
      const discount = toCurrency(Number(row.discount ?? 0));
      const netPrice = toCurrency(Number(row.net_price ?? Number(row.total_price ?? 0) - Number(row.discount ?? 0)));
      const paidTotal = toCurrency(getSalePaidTotal(row));
      const customerRemaining = toCurrency(customerRemainingAmount(row, installmentPaidBySaleUuid));
      const municipalityRemaining = toCurrency(Number(municipalityRemainingBySaleUuid.get(row.uuid) ?? 0));
      const printedAt = new Date().toLocaleString();
      const firstDueLabel = row.payment_type === "installment" ? toDateLabel(row.first_due_date ?? null) : "-";
      const planLabel =
        row.payment_type === "installment"
          ? `${String(row.frequency_type ?? "monthly")} x${Number(row.installment_count ?? 0) || 0}`
          : "full";

      const html = `<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Sale Form - ${escapeHtml(saleLabel)}</title>
    <style>
      body { font-family: Arial, sans-serif; margin: 24px; color: #0f172a; }
      .header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom: 18px; }
      .title { font-size: 24px; font-weight: 700; margin: 0 0 4px; }
      .sub { margin: 0; font-size: 12px; color: #475569; }
      .box { border:1px solid #cbd5e1; border-radius:10px; padding:14px; margin-bottom:14px; }
      .grid { display:grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px 18px; }
      .label { font-size: 12px; color: #475569; margin-bottom: 2px; }
      .value { font-size: 14px; font-weight: 600; }
      .footer { margin-top: 24px; font-size: 12px; color: #475569; }
      @media print { body { margin: 10mm; } }
    </style>
  </head>
  <body>
    <div class="header">
      <div>
        <p class="title">Apartment Sale Form</p>
        <p class="sub">Generated for finance payment processing</p>
      </div>
      <div>
        <div class="label">Printed At</div>
        <div class="value">${escapeHtml(printedAt)}</div>
      </div>
    </div>

    <div class="box">
      <div class="grid">
        <div><div class="label">Sale ID</div><div class="value">${escapeHtml(saleLabel)}</div></div>
        <div><div class="label">Sale Date</div><div class="value">${escapeHtml(saleDate)}</div></div>
        <div><div class="label">Customer</div><div class="value">${escapeHtml(customerLabel)}</div></div>
        <div><div class="label">Apartment</div><div class="value">${escapeHtml(apartmentLabel)}</div></div>
        <div><div class="label">Status</div><div class="value">${escapeHtml(String(row.status ?? ""))}</div></div>
        <div><div class="label">Payment Plan</div><div class="value">${escapeHtml(planLabel)}</div></div>
        <div><div class="label">First Due Date</div><div class="value">${escapeHtml(firstDueLabel)}</div></div>
      </div>
    </div>

    <div class="box">
      <div class="grid">
        <div><div class="label">Total Price</div><div class="value">${escapeHtml(totalPrice)}</div></div>
        <div><div class="label">Discount</div><div class="value">${escapeHtml(discount)}</div></div>
        <div><div class="label">Net Price</div><div class="value">${escapeHtml(netPrice)}</div></div>
        <div><div class="label">Paid by Customer</div><div class="value">${escapeHtml(paidTotal)}</div></div>
        <div><div class="label">Customer Remaining</div><div class="value">${escapeHtml(customerRemaining)}</div></div>
        <div><div class="label">Municipality Remaining</div><div class="value">${escapeHtml(municipalityRemaining)}</div></div>
      </div>
    </div>

    <div class="footer">
      Customer can carry this form to finance section for payment processing and record verification.
    </div>
  </body>
</html>`;

      const popup = window.open("", "_blank", "width=920,height=760");
      if (!popup) {
        notifyError("Unable to open print window. Please allow popups and try again.");
        return;
      }

      popup.document.open();
      popup.document.write(html);
      popup.document.close();
      popup.focus();
      popup.print();
    },
    [apartmentLabelById, customerLabelById, getSalePaidTotal, installmentPaidBySaleUuid, municipalityRemainingBySaleUuid]
  );

  const openDeedPrintPage = useCallback((row: ApartmentSaleRow) => {
    if (typeof window === "undefined") return;
    window.open(`/print/apartment-sales/${row.uuid}/deed`, "_blank", "noopener,noreferrer");
  }, []);

  const printDeedDocument = useCallback(
    (row: ApartmentSaleRow) => {
      if (typeof window === "undefined") return;

      const escapeHtml = (value: string): string =>
        value
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/\"/g, "&quot;")
          .replace(/'/g, "&#39;");

      const customer = customers.find((item) => Number(item.id) === Number(row.customer_id));
      const apartment = apartments.find((item) => Number(item.id) === Number(row.apartment_id));
      const customerLabel = customerLabelById.get(row.customer_id) ?? `Customer #${row.customer_id}`;
      const apartmentLabel = apartmentLabelById.get(row.apartment_id) ?? `Apartment #${row.apartment_id}`;
      const saleLabel = row.sale_id || row.uuid.slice(0, 8).toUpperCase();
      const deedDate = toPersianDate(row.deed_issued_at ?? row.updated_at ?? Date.now());
      const customerName = customer?.name ?? customerLabel.replace(/\s*\(.*\)\s*$/, "").trim();
      const customerFatherName = customer?.fname ?? "";
      const customerGrandFatherName = customer?.gname ?? "";
      const customerPhone = customer?.phone ?? customerLabel.match(/\(([^)]+)\)/)?.[1] ?? "";
      const customerPhoneAlt = customer?.phone1 ?? "";
      const [currentArea, currentDistrict, currentProvince] = splitAddressParts(customer?.address, 3);
      const [originArea, originDistrict, originProvince] = splitAddressParts(customer?.address, 3);
      const apartmentCode = apartment?.apartment_code ?? apartmentLabel.split(" - ")[0] ?? apartmentLabel;
      const apartmentUnit = apartment?.unit_number ?? apartmentLabel.match(/Unit\s*(.+)$/i)?.[1] ?? "";
      const apartmentBlock = apartment?.block_number ?? "";
      const apartmentFloor = apartment?.floor_number ?? "";
      const apartmentRooms = typeof apartment?.bedrooms === "number" && Number.isFinite(apartment.bedrooms)
        ? String(apartment.bedrooms)
        : "";
      const apartmentArea = typeof apartment?.area_sqm === "number" && Number.isFinite(apartment.area_sqm)
        ? String(apartment.area_sqm)
        : "";
      const totalPrice = Number(row.total_price ?? 0).toFixed(2);
      const netPrice = Number(row.net_price ?? Number(row.total_price ?? 0) - Number(row.discount ?? 0)).toFixed(2);
      const field = (value: unknown, fallback = "........................") => escapeHtml(toPrintableValue(value, fallback));
      const currentAddress = [currentArea, currentDistrict, currentProvince].filter(Boolean).join(" / ");
      const originAddress = [originArea, originDistrict, originProvince].filter(Boolean).join(" / ");
      const apartmentAreaLabel = apartmentArea ? `${apartmentArea} متر مربع` : "";
      const totalPriceLabel = `${totalPrice} دالر امریکایی`;
      const netPriceLabel = `${netPrice} دالر امریکایی`;
      const assetRoot = "/deed-assets";
      const assetVersion = "20260309-3";
      const cornerTopLeftSrc = `${assetRoot}/corner-top-left.png?v=${assetVersion}`;
      const cornerTopRightSrc = `${assetRoot}/corner-top-right.png?v=${assetVersion}`;
      const cornerBottomLeftSrc = `${assetRoot}/corner-bottom-left.png?v=${assetVersion}`;
      const cornerBottomRightSrc = `${assetRoot}/corner-bottom-right.png?v=${assetVersion}`;
      const logoLeftSrc = `${assetRoot}/logo-left.png?v=${assetVersion}`;
      const logoRightSrc = `${assetRoot}/logo-right.png?v=${assetVersion}`;
      const ornamentTopCenterSrc = `${assetRoot}/ornament-top-center.png?v=${assetVersion}`;
      const watermarkSvg = `
        <svg viewBox="0 0 340 460" aria-hidden="true">
          <defs>
            <linearGradient id="wm-gold" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#ead2a2" />
              <stop offset="50%" stop-color="#d6a349" />
              <stop offset="100%" stop-color="#b8882f" />
            </linearGradient>
          </defs>
          <path d="M170 38 C232 120 264 178 264 244 C264 317 222 370 170 370 C118 370 76 317 76 244 C76 178 108 120 170 38Z"
            fill="none" stroke="url(#wm-gold)" stroke-width="12" opacity=".28"/>
          <path d="M170 90 C210 146 224 188 224 230 C224 273 200 304 170 304 C140 304 116 273 116 230 C116 188 130 146 170 90Z"
            fill="none" stroke="url(#wm-gold)" stroke-width="8" opacity=".2"/>
          <path d="M86 300 C52 270 34 226 36 178" fill="none" stroke="url(#wm-gold)" stroke-width="8" opacity=".18"/>
          <path d="M254 300 C288 270 306 226 304 178" fill="none" stroke="url(#wm-gold)" stroke-width="8" opacity=".18"/>
        </svg>`;

      const html = `<!doctype html>
<html dir="rtl" lang="fa">
  <head>
    <meta charset="utf-8" />
    <title>Deed Form - ${escapeHtml(saleLabel)}</title>
    <style>
      @page { size: A4 portrait; margin: 0; }
      * { box-sizing: border-box; }
      html, body {
        margin: 0;
        padding: 0;
        background: #f3f1ec;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
      }
      body {
        font-family: "Tahoma", "Noto Naskh Arabic", sans-serif;
        color: #111827;
      }
      .wrap {
        min-height: 100dvh;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 12px;
        background: #f3f1ec;
      }
      .sheet {
        width: min(100%, 210mm);
        min-height: 297mm;
        aspect-ratio: 210 / 297;
        position: relative;
        background: #f3f1ec;
        overflow: hidden;
        border: 1.5mm solid #d6a349;
        box-shadow: 0 18px 45px rgba(15, 23, 42, 0.12);
        padding: 10mm 8mm 7mm;
      }
      .frame {
        position: absolute;
        inset: 4mm;
        border: 0.6mm solid #d6a349;
        pointer-events: none;
      }
      .content {
        position: relative;
        z-index: 1;
        min-height: calc(297mm - 17mm);
        display: flex;
        flex-direction: column;
      }
      .corner {
        position: absolute;
        width: 24mm;
        opacity: 0.92;
      }
      .corner img,
      .top-ornament img,
      .seal img,
      .watermark svg {
        width: 100%;
        height: auto;
        display: block;
      }
      .corner.tr { top: 0; right: 0; }
      .corner.tl { top: 0; left: 0; }
      .corner.br { bottom: 0; right: 0; }
      .corner.bl { bottom: 0; left: 0; }
      .top-ornament {
        position: absolute;
        top: 0.2mm;
        left: 50%;
        transform: translateX(-50%);
        width: 31mm;
      }
      .watermark {
        position: absolute;
        inset: 70mm 33mm 50mm;
        opacity: 0.12;
        pointer-events: none;
      }
      .header {
        display: grid;
        grid-template-columns: 48mm minmax(0, 1fr) 48mm;
        align-items: center;
        gap: 10mm;
        padding-inline: 18mm;
        margin-top: 5mm;
      }
      .seal {
        width: 42mm;
        height: 42mm;
        overflow: visible;
        display: flex;
        align-items: center;
        justify-content: center;
        justify-self: center;
        position: relative;
        background: #f3f1ec;
      }
      .seal.left {
        transform: none;
        justify-self: end;
        margin-right: 4mm;
      }
      .seal.right {
        transform: none;
        justify-self: start;
        margin-left: 4mm;
      }
      .seal.left::before,
      .seal.right::before {
        display: none;
      }
      .seal img {
        width: 94%;
        height: 94%;
        object-fit: contain;
        object-position: center center;
      }
      .title-block {
        text-align: center;
        width: 100%;
        max-width: 100%;
        min-width: 0;
        padding-inline: 0;
        justify-self: stretch;
        position: relative;
        z-index: 2;
        display: flex;
        flex-direction: column;
        align-items: center;
      }
      .title-block h1,
      .title-block h2,
      .title-block h3 {
        margin: 0 auto;
        font-weight: 800;
        line-height: 1.28;
        white-space: nowrap;
        width: fit-content;
        max-width: 100%;
        text-align: center;
      }
      .title-block h1 { font-size: 6.8mm; }
      .title-block h2 { font-size: 5.9mm; }
      .title-block h3 { font-size: 6.2mm; }
      .divider {
        position: relative;
        margin: 7mm 6mm 5.5mm;
        height: 4mm;
        z-index: 1;
      }
      .divider::before {
        content: "";
        position: absolute;
        inset: 1.65mm 0 0;
        height: 1.2mm;
        background: #1f1b1b;
        border-radius: 999px;
      }
      .divider::after {
        content: "";
        position: absolute;
        left: 50%;
        top: 0;
        transform: translateX(-50%);
        width: 54%;
        height: 4mm;
        background: #d6a349;
        border-radius: 999px;
      }
      .meta {
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 5mm;
        align-items: center;
        margin-bottom: 5mm;
      }
      .pill {
        background: #d6a349;
        color: #fff;
        border-radius: 999px;
        min-height: 12mm;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 7mm;
        font-size: 5.4mm;
        font-weight: 800;
      }
      .pill .line {
        display: inline-flex;
        align-items: center;
        min-width: 25mm;
        padding-inline-start: 4mm;
      }
      .hero {
        display: grid;
        grid-template-columns: 1.3fr 0.85fr;
        gap: 6mm;
        align-items: start;
      }
      .section-tag {
        display: inline-flex;
        align-items: center;
        min-height: 9mm;
        padding: 0 5mm;
        border-radius: 999px;
        background: #d6a349;
        color: #fff;
        font-size: 5mm;
        font-weight: 800;
        margin-bottom: 4mm;
      }
      .identity-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 4mm 8mm;
      }
      .fields {
        display: grid;
        gap: 2.1mm;
      }
      .fields.two {
        grid-template-columns: 1fr 1fr;
        gap: 2.1mm 7mm;
      }
      .field-row {
        display: flex;
        align-items: baseline;
        gap: 2mm;
        min-height: 7mm;
        font-size: 4.6mm;
        font-weight: 700;
      }
      .field-row .label {
        flex: 0 0 auto;
      }
      .field-row .value {
        flex: 1 1 auto;
        min-height: 6.2mm;
        border-bottom: 0.55mm dotted #111827;
        padding-inline: 1.5mm;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .photos {
        display: flex;
        gap: 4mm;
        justify-content: flex-start;
        padding-top: 7mm;
        margin-right: 30%;
      }
      .photo-box {
        width: 30mm;
        height: 46mm;
        border: 0.55mm solid #202020;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        font-size: 4.6mm;
        font-weight: 700;
        line-height: 1.35;
        background: rgba(255,255,255,0.72);
      }
      .section {
        margin-top: 4mm;
      }
      .apartment-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 2.4mm 7mm;
      }
      .statement {
        margin-top: 3mm;
        font-size: 4.6mm;
        font-weight: 700;
        line-height: 1.7;
        text-align: justify;
      }
      .statement.center {
        text-align: center;
        margin-top: 5mm;
      }
      .signatures {
        display: grid;
        grid-template-columns: 1fr 1fr 1fr;
        gap: 6mm;
        align-items: end;
        margin-top: 5mm;
      }
      .signature-title {
        text-align: center;
        font-size: 4.8mm;
        font-weight: 800;
        margin-bottom: 9mm;
      }
      .signature-line {
        border-bottom: 0.65mm solid #111827;
        min-height: 7mm;
      }
      .committee {
        display: grid;
        gap: 6mm;
      }
      .committee-row {
        display: flex;
        gap: 4mm;
        align-items: center;
        font-size: 4.5mm;
        font-weight: 700;
      }
      .committee-row .idx {
        min-width: 6mm;
      }
      .committee-row .dots {
        flex: 1 1 auto;
        border-bottom: 0.55mm dotted #111827;
        min-height: 6mm;
      }
      .note {
        margin-top: auto;
        padding-top: 5mm;
        display: grid;
        grid-template-columns: auto 1fr;
        align-items: start;
        gap: 3mm;
        font-size: 4.6mm;
        font-weight: 800;
        line-height: 1.6;
      }
      .note-label {
        background: #1f1b1b;
        color: #fff;
        border-radius: 999px;
        padding: 1mm 4mm;
        flex: 0 0 auto;
      }
      .note-text {
        min-width: 0;
      }
      @media screen and (max-width: 900px) {
        .wrap { padding: 0; }
        .sheet {
          width: 100%;
          min-height: auto;
          border-width: 1mm;
          padding: 10mm 7mm 8mm;
          box-shadow: none;
        }
        .hero,
        .identity-grid,
        .fields.two,
        .apartment-grid,
        .signatures {
          grid-template-columns: 1fr;
        }
        .photos {
          order: -1;
          justify-content: center;
          padding-top: 0;
        }
        .header {
          grid-template-columns: 1fr;
          gap: 4mm;
          padding-inline: 0;
          margin-top: 8mm;
        }
        .seal { margin: 0 auto; }
        .meta {
          grid-template-columns: 1fr;
        }
        .pill {
          font-size: 4.4mm;
          padding-inline: 4mm;
        }
        .top-ornament,
        .corner {
          opacity: 0.55;
        }
        .note {
          grid-template-columns: 1fr;
          font-size: 4.1mm;
        }
        .signature-title {
          margin-bottom: 5mm;
        }
        .statement {
          font-size: 4mm;
        }
      }
      @media print {
        html, body { width: 210mm; height: auto; background: #fff; }
        .wrap {
          padding: 0;
          min-height: auto;
          display: flex;
          justify-content: center;
          align-items: flex-start;
        }
        .sheet {
          width: 210mm;
          height: 297mm;
          min-height: 297mm;
          margin: 0 auto;
          box-shadow: none;
          break-after: avoid;
          overflow: hidden;
          padding: 7mm 6.5mm 5mm;
        }
        .content {
          min-height: calc(297mm - 12mm);
          transform: scale(0.88);
          transform-origin: top center;
          width: 100%;
          margin: 0 auto;
        }
        .frame {
          inset: 3mm;
        }
        .corner {
          width: 22mm;
        }
        .top-ornament {
          width: 28mm;
          top: 0.4mm;
        }
        .header {
          grid-template-columns: 42mm minmax(0, 1fr) 42mm;
          gap: 8mm;
          padding-inline: 16mm;
          margin-top: 5mm;
        }
        .seal {
          width: 38mm;
          height: 38mm;
          overflow: visible;
        }
        .seal.left {
          transform: none;
          justify-self: end;
          margin-right: 3mm;
          background: red-500;

        }
        .seal.right {
          transform: none;
          justify-self: start;
          margin-left: 3mm;
        }
        .title-block {
          width: 100%;
          max-width: 100%;
          padding-inline: 0;
          justify-self: stretch;
          display: flex;
          flex-direction: column;
          align-items: center;
        }
        .title-block h1 { font-size: 5.8mm; }
        .title-block h2 { font-size: 5mm; }
        .title-block h3 { font-size: 5.3mm; }
        .divider {
          margin: 5mm 7mm 4mm;
          height: 3.2mm;
        }
        .divider::before {
          inset: 1.2mm 0 0;
          height: 1mm;
        }
        .divider::after {
          height: 3.2mm;
          width: 52%;
        }
        .meta {
          gap: 4mm;
          margin-bottom: 4mm;
        }
        .pill {
          min-height: 10mm;
          padding: 0 5.5mm;
          font-size: 4.8mm;
        }
        .pill .line {
          min-width: 20mm;
          padding-inline-start: 2.5mm;
        }
        .hero {
          gap: 5mm;
        }
        .section-tag {
          min-height: 7.5mm;
          padding: 0 4mm;
          font-size: 4.3mm;
          margin-bottom: 3mm;
        }
        .identity-grid {
          gap: 3mm 6mm;
        }
        .fields {
          gap: 1.4mm;
        }
        .fields.two {
          gap: 1.4mm 5mm;
        }
        .field-row {
          min-height: 5.7mm;
          gap: 1.4mm;
          font-size: 4mm;
        }
        .field-row .value {
          min-height: 4.8mm;
          padding-inline: 1mm;
        }
        .photos {
          gap: 3mm;
          padding-top: 4mm;
          margin-right: 30%;
        }
        .photo-box {
          width: 26mm;
          height: 40mm;
          font-size: 3.9mm;
        }
        .section {
          margin-top: 3mm;
        }
        .apartment-grid {
          gap: 1.8mm 5mm;
        }
        .statement {
          margin-top: 1.6mm;
          font-size: 3.8mm;
          line-height: 1.34;
        }
        .statement.center {
          margin-top: 3mm;
        }
        .signatures {
          gap: 4mm;
          margin-top: 2.5mm;
        }
        .signature-title {
          font-size: 3.9mm;
          margin-bottom: 4.5mm;
        }
        .signature-line {
          min-height: 4mm;
        }
        .committee {
          gap: 3mm;
        }
        .committee-row {
          gap: 2.4mm;
          font-size: 3.7mm;
        }
        .committee-row .idx {
          min-width: 4mm;
        }
        .committee-row .dots {
          min-height: 4mm;
        }
        .note {
          padding-top: 2mm;
          gap: 2mm;
          font-size: 3.7mm;
          line-height: 1.28;
        }
        .note-label {
          padding: 0.5mm 2.5mm;
        }
      }
    </style>
  </head>
  <body>
    <div class="wrap">
      <div class="sheet">
        <div class="frame"></div>
        <div class="corner tr"><img src="${cornerTopRightSrc}" alt="" /></div>
        <div class="corner tl"><img src="${cornerTopLeftSrc}" alt="" /></div>
        <div class="corner br"><img src="${cornerBottomRightSrc}" alt="" /></div>
        <div class="corner bl"><img src="${cornerBottomLeftSrc}" alt="" /></div>
        <div class="top-ornament"><img src="${ornamentTopCenterSrc}" alt="" /></div>
        <div class="watermark">${watermarkSvg}</div>

        <div class="content">
        <header class="header">
          <div class="seal left"><img src="${logoLeftSrc}" alt="" /></div>
          <div class="title-block">
          
            <h1>ریاست شرکت ساختمانی شاداب ظفر</h1>
            <h2>معاونیت اداری</h2>
            <h3>مدیریت توزیع آپارتمانها</h3>
          </div>
          <div class="seal right"><img src="${logoRightSrc}" alt="" /></div>
        </header>

        <div class="divider"></div>

        <section class="meta">
          <div class="pill">
            <span>فورمه توزیع</span>
            <span class="line">${field(saleLabel)}</span>
          </div>
          <div class="pill">
            <span>تاریخ</span>
            <span class="line">${field(deedDate)}</span>
          </div>
        </section>

        <section class="hero">
          <div>
            <div class="section-tag">الف: شهرت مشتری:</div>
            <div class="identity-grid">
              <div class="fields">
                <div class="field-row"><span class="label">اسم:</span><span class="value">${field(customerName)}</span></div>
                <div class="field-row"><span class="label">ولد:</span><span class="value">${field(customerFatherName)}</span></div>
                <div class="field-row"><span class="label">وظیفه:</span><span class="value">${field("")}</span></div>
                <div class="field-row"><span class="label">نمبر تذکره:</span><span class="value">${field("")}</span></div>
                <div class="field-row"><span class="label">قریه/ناحیه:</span><span class="value">${field(currentArea)}</span></div>
                <div class="field-row"><span class="label">ولسوالی:</span><span class="value">${field(currentDistrict)}</span></div>
                <div class="field-row"><span class="label">ولایت:</span><span class="value">${field(currentProvince)}</span></div>
              </div>
              <div class="fields">
                <div class="field-row"><span class="label">سکونت فعلی مشتری:</span><span class="value">${field(currentAddress)}</span></div>
                <div class="field-row"><span class="label">سکونت اصلی مشتری:</span><span class="value">${field(originAddress)}</span></div>
                <div class="field-row"><span class="label">شماره تماس:</span><span class="value">${field(customerPhone)}</span></div>
                <div class="field-row"><span class="label">شماره دوم:</span><span class="value">${field(customerPhoneAlt)}</span></div>
                <div class="field-row"><span class="label">نام پدرکلان:</span><span class="value">${field(customerGrandFatherName)}</span></div>
                <div class="field-row"><span class="label">مرجع ثبت:</span><span class="value">${field(saleLabel)}</span></div>
              </div>
            </div>
          </div>
          <div class="photos">
            <div class="photo-box">عکس<br />مشتری</div>
            <div class="photo-box">عکس<br />وکیل<br />مشتری</div>
          </div>
        </section>

        <section class="section">
          <div class="section-tag">ب: شهرت وکیل مشتری:</div>
          <div class="fields two">
            <div class="field-row"><span class="label">اسم:</span><span class="value">${field("")}</span></div>
            <div class="field-row"><span class="label">ولد:</span><span class="value">${field("")}</span></div>
            <div class="field-row"><span class="label">ولدیت:</span><span class="value">${field("")}</span></div>
            <div class="field-row"><span class="label">نمبر تذکره:</span><span class="value">${field("")}</span></div>
            <div class="field-row"><span class="label">قرابت با مشتری:</span><span class="value">${field("")}</span></div>
            <div class="field-row"><span class="label">نمبر تلفون:</span><span class="value">${field("")}</span></div>
            <div class="field-row"><span class="label">سکونت فعلی:</span><span class="value">${field("")}</span></div>
            <div class="field-row"><span class="label">سکونت اصلی:</span><span class="value">${field("")}</span></div>
          </div>
        </section>

        <section class="section">
          <div class="section-tag">ج: مشخصات آپارتمان:</div>
          <div class="apartment-grid">
            <div class="field-row"><span class="label">نمبر آپارتمان:</span><span class="value">${field(apartmentCode)}</span></div>
            <div class="field-row"><span class="label">نمبر بلاک:</span><span class="value">${field(apartmentBlock)}</span></div>
            <div class="field-row"><span class="label">منزل:</span><span class="value">${field(apartmentFloor)}</span></div>
            <div class="field-row"><span class="label">تعداد اتاق:</span><span class="value">${field(apartmentRooms)}</span></div>
            <div class="field-row"><span class="label">به مساحت:</span><span class="value">${field(apartmentAreaLabel)}</span></div>
            <div class="field-row"><span class="label">واحد:</span><span class="value">${field(apartmentUnit)}</span></div>
            <div class="field-row"><span class="label">قیمت سهم شرکت:</span><span class="value">${field(netPriceLabel)}</span></div>
            <div class="field-row"><span class="label">مناصفه قیمت کل:</span><span class="value">${field(totalPriceLabel)}</span></div>
            <div class="field-row"><span class="label">حدود اربعه آپارتمان:</span><span class="value">${field("")}</span></div>
          </div>
        </section>

        <div class="statement">
          تحویلی سهم فیصدي شاروالی کابل و پول قباله شرعی بدوش مشتری محترم میباشد که به مراجع مربوطه تحویل نماید.
        </div>
        <div class="statement">
          اینجانب که شهرتم در فوق ذکر است به مندرجات فورمه هذا متعهد بوده و به آن موافقت کامل دارم.
        </div>
        <div class="statement center">(شصت و امضای مشتری)</div>

        <section class="section">
          <div class="section-tag">د:</div>
          <div class="statement" style="margin-top: 0;">
            شرکت ساختمانی و خانه سازی شاداب ظفر متعهد است که آپارتمان مندرجه فورمه هذا را بعد از اعمار به دسترس مشتری مذکور قرار دهد.
          </div>
        </section>

        <section class="signatures">
          <div>
            <div class="signature-title">امضای کمیسیون توزیع</div>
            <div class="committee">
              <div class="committee-row"><span class="idx">۱-</span><span class="dots"></span></div>
              <div class="committee-row"><span class="idx">۲-</span><span class="dots"></span></div>
              <div class="committee-row"><span class="idx">۳-</span><span class="dots"></span></div>
            </div>
          </div>
          <div>
            <div class="signature-title">مدیر توزیع آپارتمانها</div>
            <div class="signature-line"></div>
          </div>
          <div>
            <div class="signature-title">رئیس شرکت ساختمانی شاداب ظفر</div>
            <div class="signature-line"></div>
          </div>
        </section>

        <div class="note">
          <span class="note-label">نوت:</span>
          <span class="note-text">فورمه هذا در سه کاپی ترتیب شده که کاپی به شاروالی، کاپی به شرکت و کاپی به مشتری یا وکیل وی بعد از طی مراحل داده میشود.</span>
        </div>
        </div>
      </div>
    </div>
    <script>
      window.addEventListener("load", function () {
        setTimeout(function () {
          window.focus();
          window.print();
        }, 250);
      });
    </script>
  </body>
</html>`;

      const popup = window.open("", "_blank", "width=980,height=860");
      if (!popup) {
        notifyError("Unable to open deed print window. Please allow popups and try again.");
        return;
      }

      popup.document.open();
      popup.document.write(html);
      popup.document.close();
    },
    [apartments, apartmentLabelById, customerLabelById, customers]
  );

  const salesColumns = useMemo(
    () =>
      createApartmentSalesColumns({
        customerLabelById,
        apartmentLabelById,
        onPrintSale: printSaleDocument,
        onPrintDeed: openDeedPrintPage,
        canManageSales,
        canIssueDeed: canApproveDeed,
        installmentPaidBySaleUuid,
        municipalityRemainingBySaleUuid,
        onHandoverKey: canManageSales ? openHandoverDialog : undefined,
        onTerminate: canManageSales ? openTerminateDialog : undefined,
        onIssueDeed: canApproveDeed ? openIssueDeedDialog : undefined,
      }),
    [
      apartmentLabelById,
      canApproveDeed,
      canManageSales,
      customerLabelById,
      installmentPaidBySaleUuid,
      municipalityRemainingBySaleUuid,
      openHandoverDialog,
      openIssueDeedDialog,
      openDeedPrintPage,
      printSaleDocument,
      openTerminateDialog,
    ]
  );

  const renderExpandedSaleRow = useCallback(
    (row: ApartmentSaleRow) => {
      const customerLabel = customerLabelById.get(row.customer_id) ?? `Customer #${row.customer_id}`;
      const apartmentLabel = apartmentLabelById.get(row.apartment_id) ?? `Apartment #${row.apartment_id}`;
      const paidTotal = getSalePaidTotal(row);
      const customerRemaining = customerRemainingAmount(row, installmentPaidBySaleUuid);

      const municipalityRemainingRaw = municipalityRemainingBySaleUuid.get(row.uuid);
      const municipalityRemaining =
        typeof municipalityRemainingRaw === "number" && Number.isFinite(municipalityRemainingRaw)
          ? Math.max(0, municipalityRemainingRaw)
          : 0;

      return (
        <ApartmentSaleExpandedRow
          row={row}
          customerLabel={customerLabel}
          apartmentLabel={apartmentLabel}
          paidTotal={paidTotal}
          customerRemaining={customerRemaining}
          municipalityRemaining={municipalityRemaining}
        />
      );
    },
    [apartmentLabelById, customerLabelById, getSalePaidTotal, installmentPaidBySaleUuid, municipalityRemainingBySaleUuid]
  );

  const applyApartmentSelection = useCallback(
    (apartmentId: string) => {
      setForm((prev) => {
        const selected = apartments.find((item) => String(item.id) === apartmentId);
        const totalPrice =
          selected && typeof selected.total_price === "number" && Number.isFinite(selected.total_price)
            ? selected.total_price
            : null;

        return {
          ...prev,
          apartment_id: apartmentId,
          total_price: totalPrice !== null ? String(totalPrice) : prev.total_price,
        };
      });
    },
    [apartments]
  );

  const closeForm = useCallback(() => {
    setEditingUuid(null);
    setFormError(null);
    setForm(createEmptyApartmentSaleForm());
  }, []);

  const openEditForm = useCallback(
    (row: ApartmentSaleRow) => {
      if (readOnly) {
        notifyError(READ_ONLY_MESSAGE);
        return;
      }

      const scope = resolveRowEditScope(row);
      if (scope === "none") {
        notifyError("Sale is locked. Use Financials button for breakdown and receipts.");
        return;
      }

      setEditingUuid(row.uuid);
      setFormError(null);
      setForm(toForm(row));
    },
    [readOnly]
  );

  const openDeleteDialog = useCallback(
    (row: ApartmentSaleRow) => {
      if (readOnly) {
        notifyError(READ_ONLY_MESSAGE);
        return;
      }

      if (resolveRowEditScope(row) !== "full") {
        notifyError("Sale cannot be deleted after approval, payment, completion, or cancellation.");
        return;
      }

      setPendingDelete(row);
    },
    [readOnly]
  );

  const handleSave = useCallback(async () => {
    if (readOnly) {
      notifyError(READ_ONLY_MESSAGE);
      return;
    }
    if (saving) return;

    setSaving(true);
    setFormError(null);

    try {
      const payload = buildSalePayload(form);
      if (!editingUuid) {
        setFormError("Only edit mode is allowed in this section.");
        return;
      }

      await apartmentSaleUpdate(editingUuid, payload);
      closeForm();
      await refresh();
    } catch (error: unknown) {
      setFormError(error instanceof Error ? error.message : "Save failed.");
    } finally {
      setSaving(false);
    }
  }, [closeForm, editingUuid, form, readOnly, refresh, saving]);

  const handleDelete = useCallback(async () => {
    if (readOnly) {
      notifyError(READ_ONLY_MESSAGE);
      return;
    }
    if (!pendingDelete?.uuid) return;

    try {
      await apartmentSaleDelete(pendingDelete.uuid);
      if (editingUuid === pendingDelete.uuid) closeForm();
      setPendingDelete(null);
      await refresh();
    } catch (error: unknown) {
      notifyError(error instanceof Error ? error.message : "Delete failed.");
    }
  }, [closeForm, editingUuid, pendingDelete, readOnly, refresh]);

  const handleHandoverKey = useCallback(async () => {
    if (!canManageSales) {
      notifyError("You do not have permission to hand over keys.");
      return;
    }
    if (!pendingHandover?.uuid || handoverSubmitting) return;

    setHandoverSubmitting(true);
    setHandoverError(null);
    try {
      await apartmentSaleHandoverKey(pendingHandover.uuid);
      setPendingHandover(null);
      await refresh();
    } catch (error: unknown) {
      setHandoverError(error instanceof Error ? error.message : "Failed to hand over key.");
    } finally {
      setHandoverSubmitting(false);
    }
  }, [canManageSales, handoverSubmitting, pendingHandover, refresh]);

  const handleTerminate = useCallback(async () => {
    if (!canManageSales) {
      notifyError("You do not have permission to terminate sales.");
      return;
    }
    if (!pendingTerminate?.uuid || terminateSubmitting) return;

    const reason = terminateForm.reason.trim();
    if (!reason) {
      setTerminateError("Termination reason is required.");
      return;
    }

    const charge = Number(terminateForm.termination_charge);
    if (!Number.isFinite(charge) || charge < 0) {
      setTerminateError("Termination charge must be 0 or positive number.");
      return;
    }

    const paidTotal = getSalePaidTotal(pendingTerminate);
    if (charge > paidTotal + 0.0001) {
      setTerminateError(`Termination charge cannot exceed paid amount (${paidTotal.toFixed(2)} USD).`);
      return;
    }

    const minDefaultCharge = defaultedMinCharge(paidTotal);
    if (terminateForm.status === "defaulted" && charge + 0.0001 < minDefaultCharge) {
      setTerminateError(`Defaulted status requires at least ${minDefaultCharge.toFixed(2)} USD charge.`);
      return;
    }

    const payload: ApartmentSaleTerminateInput = {
      reason,
      status: terminateForm.status,
      vacated_at: terminateForm.vacated_at || undefined,
      termination_charge: charge,
    };

    setTerminateSubmitting(true);
    setTerminateError(null);
    try {
      await apartmentSaleTerminate(pendingTerminate.uuid, payload);
      setPendingTerminate(null);
      await refresh();
    } catch (error: unknown) {
      setTerminateError(error instanceof Error ? error.message : "Failed to terminate sale.");
    } finally {
      setTerminateSubmitting(false);
    }
  }, [canManageSales, defaultedMinCharge, getSalePaidTotal, pendingTerminate, refresh, terminateForm, terminateSubmitting]);

  const handleIssueDeed = useCallback(async () => {
    if (!canApproveDeed) {
      notifyError("Only admin users can approve and issue ownership deed.");
      return;
    }
    if (!pendingIssueDeed?.uuid || deedIssuing) return;

    setDeedIssuing(true);
    setDeedIssueError(null);
    try {
      await apartmentSaleIssueDeed(pendingIssueDeed.uuid);
      setPendingIssueDeed(null);
      await refresh();
    } catch (error: unknown) {
      setDeedIssueError(error instanceof Error ? error.message : "Failed to issue ownership deed.");
    } finally {
      setDeedIssuing(false);
    }
  }, [canApproveDeed, deedIssuing, pendingIssueDeed, refresh]);

  const terminatePaidTotal = useMemo(() => getSalePaidTotal(pendingTerminate), [getSalePaidTotal, pendingTerminate]);
  const terminateDefaultedMinCharge = useMemo(
    () => defaultedMinCharge(terminatePaidTotal),
    [defaultedMinCharge, terminatePaidTotal]
  );
  const terminateSuggestedCharge = useMemo(
    () => suggestedCharge(terminateForm.status, terminatePaidTotal),
    [suggestedCharge, terminateForm.status, terminatePaidTotal]
  );

  return (
    <ApartmentSalesContentView
      formOpen={Boolean(editingUuid)}
      form={form}
      formError={formError}
      saving={saving}
      customerOptions={customerOptions}
      apartmentOptions={apartmentOptions}
      onApartmentSelect={applyApartmentSelection}
      onFormChange={setForm}
      onFormCancel={closeForm}
      onFormSubmit={() => {
        void handleSave();
      }}
      rows={rows}
      loading={loading}
      salesColumns={salesColumns}
      renderExpandedSaleRow={renderExpandedSaleRow}
      onEdit={readOnly ? undefined : openEditForm}
      onDelete={readOnly ? undefined : openDeleteDialog}
      dialogsProps={{
        pendingDelete,
        onCloseDelete: () => setPendingDelete(null),
        onConfirmDelete: () => {
          void handleDelete();
        },
        pendingHandover,
        handoverSubmitting,
        handoverError,
        onCloseHandover: () => {
          if (handoverSubmitting) return;
          setPendingHandover(null);
          setHandoverError(null);
        },
        onConfirmHandover: () => {
          void handleHandoverKey();
        },
        pendingTerminate,
        terminateSubmitting,
        terminateError,
        terminateForm,
        onTerminateFormChange: setTerminateForm,
        onTerminateStatusChange: (nextStatus) => {
          const paidTotal = getSalePaidTotal(pendingTerminate);
          const charge = suggestedCharge(nextStatus, paidTotal);
          setTerminateForm((prev) => ({
            ...prev,
            status: nextStatus,
            termination_charge: String(charge),
          }));
        },
        terminatePaidTotal,
        terminateSuggestedCharge,
        terminateDefaultedMinCharge,
        onCloseTerminate: () => {
          if (terminateSubmitting) return;
          setPendingTerminate(null);
          setTerminateError(null);
        },
        onConfirmTerminate: () => {
          void handleTerminate();
        },
        pendingIssueDeed,
        deedIssuing,
        deedIssueError,
        onCloseIssueDeed: () => {
          if (deedIssuing) return;
          setPendingIssueDeed(null);
          setDeedIssueError(null);
        },
        onConfirmIssueDeed: () => {
          void handleIssueDeed();
        },
      }}
    />
  );
}
