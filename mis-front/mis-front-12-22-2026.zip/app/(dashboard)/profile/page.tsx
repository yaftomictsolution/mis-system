"use client";

import { useMemo } from "react";
import { useSelector } from "react-redux";
import { PageHeader } from "@/components/ui/PageHeader";
import type { RootState } from "@/store/store";

export default function ProfilePage() {
  const user = useSelector((state: RootState) => state.auth.user);

  const roles = useMemo(() => {
    const list = Array.isArray(user?.roles) ? user.roles : [];
    return list.filter((item) => typeof item === "string" && item.trim() !== "");
  }, [user?.roles]);

  const permissions = useMemo(() => user?.permissions ?? [], [user?.permissions]);

  return (
    <div className="mx-auto max-w-4xl p-6 lg:p-8 space-y-6">
      <PageHeader title="My Profile" subtitle="Your current authenticated account details" />

      <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-[#2a2a3e] dark:bg-[#12121a]">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div>
            <p className="text-xs text-slate-500">Full Name</p>
            <p className="mt-1 text-sm font-semibold text-slate-900 dark:text-white">{user?.full_name || "-"}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Email</p>
            <p className="mt-1 text-sm font-semibold text-slate-900 dark:text-white">{user?.email || "-"}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500">User ID</p>
            <p className="mt-1 text-sm font-semibold text-slate-900 dark:text-white">{user?.id ?? "-"}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500">UUID</p>
            <p className="mt-1 break-all text-sm font-semibold text-slate-900 dark:text-white">{user?.uuid || "-"}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-[#2a2a3e] dark:bg-[#12121a]">
          <p className="text-sm font-semibold text-slate-900 dark:text-white">Roles</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {roles.length ? (
              roles.map((role) => (
                <span
                  key={role}
                  className="rounded-full border border-blue-200 bg-blue-50 px-2.5 py-1 text-xs font-medium text-blue-700 dark:border-blue-500/30 dark:bg-blue-500/10 dark:text-blue-300"
                >
                  {role}
                </span>
              ))
            ) : (
              <p className="text-xs text-slate-500">No roles found.</p>
            )}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-[#2a2a3e] dark:bg-[#12121a]">
          <p className="text-sm font-semibold text-slate-900 dark:text-white">Permissions</p>
          <p className="mt-1 text-xs text-slate-500">{permissions.length} permission(s)</p>
          <div className="mt-3 max-h-40 space-y-1 overflow-y-auto pr-1">
            {permissions.length ? (
              permissions.map((perm) => (
                <p key={perm} className="rounded-md bg-slate-50 px-2 py-1 text-xs text-slate-700 dark:bg-[#1a1a2e] dark:text-slate-300">
                  {perm}
                </p>
              ))
            ) : (
              <p className="text-xs text-slate-500">No permissions found.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

